const mongoose = require('mongoose');
const { Schema } = mongoose;

const packingSlipSchema = new Schema(
    {
        packingID: {
            type: String,
        },
        orderDetails: {
            type: Schema.Types.ObjectId,
            ref: 'Order',
        },
        receivedSign: {
            type: String, // Store the image path as a string
            required: true,
        },
    },
    { timestamps: true }
);

const PackingSlip = mongoose.model('PackingSlip', packingSlipSchema); // Make sure to name the model correctly
module.exports = PackingSlip;
