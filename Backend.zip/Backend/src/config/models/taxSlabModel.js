const mongoose = require('mongoose');

const taxSlabSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        uppercase: true,
        trim: true,
        unique: true
    },
    gst: {
        type: Number,
        required: true,
    },
    hst: {
        type: Number,
        required: true,
    },
    status: {
        type: String,
        enum: ['ACTIVE', 'DELETED'],
        default: 'ACTIVE',
        uppercase: true,
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('taxslabs', taxSlabSchema);
