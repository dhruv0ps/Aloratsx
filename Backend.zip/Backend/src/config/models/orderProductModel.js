const mongoose = require("mongoose");
const { Schema } = mongoose;

// Define product reference and child SKU with quantity in order schema
const orderProductSchema = new Schema({
  product: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Product",
    required: true,
  },
  childSKU: { type: String, required: true },
  quantity: { type: Number, required: true },
  price: { type: Number, required: true },
  description: { type: String, required: true },
});

module.exports = orderProductSchema;
