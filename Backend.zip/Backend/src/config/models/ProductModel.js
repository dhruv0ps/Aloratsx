const mongoose = require("mongoose");
const childSchema = require("./childModel");
const { Schema } = mongoose;

const productSchema = new Schema(
  {

    name: { type: String, required: true, trim: true },
    ID: { type: String, required: true, trim: true, unique: true },
    children: [childSchema],
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category',
      required: true
    },
    Description:{
      type:String,
      required:true,
    },
    heroImage: {
      type: String,
      required: true
    },
  },
  {
    timestamps: true
  }
);
const Product = mongoose.model("Product", productSchema);
module.exports = Product;
