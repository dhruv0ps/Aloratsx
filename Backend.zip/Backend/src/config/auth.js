const jwtService = require('../services/jwt-service');
const ApprovedDealer = require('../config/models/dealerApproved');

module.exports.authenticateToken = async (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');

    if (!token) {
        return res.status(401).json({ error: 'No token provided' });
    }

    try {
        const decoded = await jwtService.verifyToken(token); // Ensure verifyToken is used as a promise
        const user = await ApprovedDealer.findOne({ _id: decoded.id, token });

        if (!user) {
            throw new Error('Dealer not found');
        }

        req.token = token;
        req.user = user;
        next();
    } catch (error) {
        console.error(error); // Log error details for debugging
        res.status(401).json({ error: 'Please authenticate' });
    }
};

