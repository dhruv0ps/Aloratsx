const express = require("express")
var router = express.Router();
var bodyParser = require("body-parser")

const { imageUpload, fileUpload } = require("../config/multerConfig");
const { checkPermission } = require('../config/permission');
const { authenticateToken } = require("../config/auth");

const productController = require("../controllers/productController")
const configController = require("../controllers/colorcategoryController")
const dealerController = require("../controllers/dealerController")
const orderController = require('../controllers/orderController');
const packingController = require("../controllers/packingSlipController");
const invoiceController = require("../controllers/invoiceController");
const transactionController = require("../controllers/transactionController");

var jsonParser = bodyParser.json()
router.use(jsonParser)

// #region Products
router.post('/product/add', imageUpload.fields([
    { name: 'heroImage', maxCount: 1 },
    { name: 'childrenImages', maxCount: 30 }
]), productController.addProduct);  
router.get('/product/:id', productController.getProductById);
router.post('/product/:id', imageUpload.fields([
    { name: 'heroImage', maxCount: 1 },
    { name: 'childrenImages', maxCount: 30 }
]), productController.updateProduct);
router.post('/product/', productController.getAllProducts);

// Color Routes
router.post('/colors', configController.addColor);
router.get('/colors', configController.getAllColors);
router.put('/colors/:id', configController.updateColor);
router.delete('/colors/:id', configController.deleteColor);

// Category Routes with image upload for category image
router.post('/categories', imageUpload.single('image'), configController.addCategory);
router.get('/categories', configController.getAllCategories);
router.put('/categories/:id', imageUpload.single('image'), configController.updateCategory);
router.delete('/categories/:id', configController.deleteCategory);

// tax slabs
router.post('/taxslab/add', configController.addTax);
router.get('/taxslab', configController.getAllTaxSlabs);
router.put('/taxslab/:id', configController.updateTaxSlab);

// #region Dealer
router.get("/tempdealer", dealerController.getAllDealers);
router.get('/tempdealer/:id' , dealerController.getTempDealerById);
router.post("/tempdealer/add", dealerController.createDealer);
router.post("/tempdealer/:id", dealerController.deleteDealer);

router.post('/dealers/add', dealerController.createApprovedDealer);
router.post('/dealers/login'  , dealerController.dealerLogin);
router.get('/dealers', dealerController.getAllApprovedDealers);
router.get('/dealers/:id', dealerController.getApprovedDealerById);
router.put('/dealers/:id', dealerController.updateApprovedDealer);

// #region order
router.post('/orders', orderController.createOrder);
router.put('/orders/:id', orderController.updateOrder);
router.get('/orders/:id', orderController.getOrderById);
router.get('/getorders/pending', orderController.getPendingOrders);
router.get('/getorders/approved', orderController.getApprovedOrders);
router.post('/orders/dealer', orderController.getOrderByDealerId);
router.post('/orders/po', orderController.getOrderByOrderNUmbr);

// # Packing Slip
router.post('/packing/add', imageUpload.single('receivedSign'), packingController.createPackingSlip)
router.get('/packing' , packingController.getAllPackingSlips);
router.get('/packing/:packingID' , packingController.getPackingSlipById);
router.post('/packing/packing' , packingController.getPackingSlipBypackingId);

// #Invoice 
router.post('/invoice/add', invoiceController.createInvoice);
router.get("/invoice", invoiceController.getAllInvoices);
router.get("/invoice/:id", invoiceController.getInvoiceById);
router.post("/invoice/list", invoiceController.getInvoiceListbyDealerName);

// #Transaction Controller
router.post("/transaction/create" , transactionController.createTransaction);
router.get("/transaction" , transactionController.getTransactions);
router.put("/transaction/update/:transactionId" , transactionController.updateTransactionController);
router.delete("/transaction/delete" , transactionController.deleteTransactionController);

module.exports = router;