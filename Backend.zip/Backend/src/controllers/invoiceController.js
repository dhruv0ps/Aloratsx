const InvoiceService = require("../services/invoiceServies"); // Adjust the path as necessary

// Controller for generating an invoice
module.exports.createInvoice = async (req, res) => {
  try {
    const invoiceData = req.body;
    const newInvoice = await InvoiceService.generateInvoice(invoiceData);

    return res.status(201).json({
      message: "Invoice generated successfully",
      invoice: newInvoice,
    });
  } catch (error) {
    return res.status(500).json({
      message: "Failed to generate invoice",
      error: error.message,
    });
  }
};

module.exports.getAllInvoices = async (req, res) => {
  try {
    // Call the service function to get all invoices
    const invoices = await InvoiceService.getAllInvoices();

    // Respond with the list of invoices
    res.status(200).json({
      message: "Invoices retrieved successfully",
      invoices,
    });
  } catch (error) {
    // Handle errors and send a response
    res.status(500).json({
      message: "Failed to retrieve invoices",
      error: error.message,
    });
  }
};

module.exports.getInvoiceById = async (req, res) => {
  const { id } = req.params; // Get invoice ID from request parameters

  try {
    // Call the service function to get the invoice by ID
    const invoice = await InvoiceService.getInvoiceById(id);

    // Respond with the invoice details
    res.status(200).json({
      message: "Invoice retrieved successfully",
      invoice,
    });
  } catch (error) {
    // Handle errors and send a response
    res.status(500).json({
      message: "Failed to retrieve invoice",
      error: error.message,
    });
  }
};

module.exports.getInvoiceListbyDealerName = async(req,res) => {
  const { id } = req.body; 
  try {
    const invoice = await InvoiceService.getInvoiceListbyDealer(id);

    res.status(200).json({
      message: "Invoice retrieved successfully",
      invoice,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to retrieve invoice",
      error: error.message,
    });
  }
}