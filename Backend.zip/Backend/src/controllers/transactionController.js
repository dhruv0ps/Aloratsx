const {
  createTransaction,
  getAllTransaction,
  updateTransaction,
  deleteTransaction,
} = require("../services/transactionService"); // Adjust the path as needed

// Controller function to handle transaction creation
module.exports.createTransaction = async (req, res) => {
  try {
    const transactionData = req.body;

    const transaction = await createTransaction(transactionData);

    res.status(201).json({
      message: "Transaction created successfully",
      transaction,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      message: "Failed to create transaction",
      error: error.message,
    });
  }
};

module.exports.getTransactions = async (req, res) => {
  try {
    // Fetch transactions using the service method
    const transactions = await getAllTransaction();

    // Check if the transactions are available
    if (transactions && transactions.length > 0) {
      res.status(200).json({
        message: "Transactions fetched successfully",
        transaction: {
          message: "Transaction fetched Successfully",
          transactions: transactions,
        },
      });
    } else {
      res.status(404).json({
        message: "No transactions found",
      });
    }
  } catch (error) {
    console.error("Error fetching transactions:", error); // Log the error
    res.status(500).json({
      message: "Failed to fetch transactions",
      error: error.message,
    });
  }
};

exports.updateTransactionController = async (req, res) => {
  const { transactionId } = req.params; // Get transactionId from request parameters
  const updateData = req.body; // Get update data from request body

  try {
    // Call the service function to update the transaction
    const result = await updateTransaction(transactionId, updateData);

    // Respond with the success message and updated transaction data
    res.status(200).json(result);
  } catch (error) {
    // Respond with an error message and status code
    res.status(500).json({
      message: "Failed to update transaction",
      error: error.message,
    });
  }
};

exports.deleteTransactionController = async (req, res) => {
  const { transactionId } = req.body; // Get transactionId from request parameters

  try {
    // Call the service function to delete the transaction
    const result = await deleteTransaction(transactionId);

    // Respond with the success message
    res.status(200).json(result);
  } catch (error) {
    // Respond with an error message and status code
    res.status(500).json({
      message: "Failed to delete transaction",
      error: error.message,
    });
  }
};
