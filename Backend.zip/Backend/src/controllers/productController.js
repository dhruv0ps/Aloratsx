const productServices = require('../services/productService');
const fs = require('fs');
const path = require('path');

class ProductController {
    addProduct = async (req, res, next) => {
        try {
            const productData = JSON.parse(req.body.productData);
            const childrenData = JSON.parse(req.body.childrenData);

            const heroImage = req.files['heroImage'] ? req.files['heroImage'][0] : null;
            const childrenImages = req.files['childrenImages'] || [];

            const fullProductData = {
                ...productData,
                heroImage: heroImage ? heroImage.path : null,
                children: childrenData.map((child, index) => ({
                    ...child,
                    image: childrenImages[index] ? {
                        filename: childrenImages[index].filename,
                        path: childrenImages[index].path
                    } : null
                }))
            };

            const product = await productServices.addProduct(fullProductData);
            return res.json({ status: true, data: product, err: {} });
        } catch (error) {
            return res.json({ status: false, data: {}, err: error.message });
        }
    };

    getProductById = async (req, res, next) => {
        try {
            const product = await productServices.getProductById(req.params.id);
            if (product) {
                return res.json({ status: true, data: product, err: {} });
            } else {
                return res.json({ status: false, data: {}, err: "Product not found" });
            }
        } catch (error) {
            return res.json({ status: false, data: {}, err: error.message });
        }
    };

    getAllProducts = async (req, res, next) => {
        try {
            const { page, limit, filters } = req.body;
            const products = await productServices.getAllPagedProducts(parseInt(page), parseInt(limit), filters);
            return res.json({ status: true, data: products, err: {} });
        } catch (error) {
            return res.json({ status: false, data: {}, err: error.message });
        }
    };
    

    updateProduct = async (req, res, next) => {
        try {
            // console.log(req.body.productData)
            const productData = JSON.parse(req.body.productData);
            const childrenData = JSON.parse(req.body.childrenData);

            const heroImage = req.files.length > 0 ? req.files.find(file => file.fieldname === 'heroImage') : undefined;
            const childrenImages = req.files.length > 0 ? req.files.filter(file => file.fieldname === 'childrenImages') : [];

            const existingProduct = await productServices.getProductById(req.params.id);

            const fullProductData = {
                ...productData,
                heroImage: heroImage ? heroImage.path : existingProduct.heroImage,
                children: childrenData.map((child, index) => {
                    const existingChild = existingProduct.children.find(c => c.SKU === child.SKU);
                    return {
                        ...child,
                        image: childrenImages[index] ? {
                            filename: childrenImages[index].filename,
                            path: childrenImages[index].path
                        } : (existingChild ? existingChild.image : null)
                    };
                })
            };

            const product = await productServices.updateProduct(req.params.id, fullProductData);
            return res.json({ status: true, data: product, err: {} });
        } catch (error) {
            console.log(error)
            return res.json({ status: false, data: {}, err: error.message });
        }
    };

    getNextProductId = async (req, res, next) => {
        try {
            const nextId = await productServices.getPreSaveID();
            return res.json({ status: true, data: { nextProductId: nextId }, err: {} });
        } catch (error) {
            return res.json({ status: false, data: {}, err: error.message });
        }
    };
}

module.exports = new ProductController();