const PackingSlipService = require("../services/packingSlipServices");

// Controller to generate packing slip
module.exports.createPackingSlip = async (req, res) => {
  try {
    const packingSlipData = {
      packingID: req.body.packingID,
      orderDetails: req.body.orderDetails, // Order ID
      receivedSign: req.file.path, // Multer file path for image
    };

    // Call the service to generate the packing slip
    const packingSlip = await PackingSlipService.generatePackingSlip(
      packingSlipData
    );

    return res.json({ status: true, data: packingSlip });
  } catch (error) {
    return res.json({ status: false, data: {}, err: error.message });
  }
};

module.exports.createPackingSlipOrderId = async(req,res) => {
  try {
    const packingSlipData = {
      packingID: req.body.packingID,
      orderDetails: req.body.orderDetails, // Order ID
      receivedSign: req.file.path, // Multer file path for image
    };

    // Call the service to generate the packing slip
    const packingSlip = await PackingSlipService.generatePackingSlip(
      packingSlipData
    );

    return res.json({ status: true, data: packingSlip });
  } catch (error) {
    return res.json({ status: false, data: {}, err: error.message });
  }
};

module.exports.getAllPackingSlips = async (req, res) => {
  try {
    const packingSlips = await PackingSlipService.getAllPackingSlips();
    return res.json({ status: true, data: packingSlips });
  } catch (error) {
    return res.json({ status: false, data: [], err: error.message });
  }
};

module.exports.getPackingSlipById = async (req, res) => {
  try {
    const { packingID } = req.params; // Get packingID from route params
    const packingSlip = await PackingSlipService.getPackingSlipById(packingID);
    return res.json({ status: true, data: packingSlip });
  } catch (error) {
    return res.json({ status: false, data: {}, err: error.message });
  }
};

module.exports.getPackingSlipBypackingId = async (req, res) => {
  try {
    const { packingId } = req.body; 
    const packingSlip = await PackingSlipService.getPackingSlipByPackingId(packingId);
    console.log(packingSlip)
    console.log(packingId);
    return res.json({ status: true, data: packingSlip });
  } catch (error) {
    return res.json({ status: false, data: {}, err: error.message });
  }
};