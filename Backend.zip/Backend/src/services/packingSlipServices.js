const mongoose = require("mongoose");
const PackingSlip = require("../config/models/packingslipModel");
const Order = require("../config/models/orderModel");

// Service to generate packing slip
module.exports.generatePackingSlip = async (packingSlipData) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    // Validate input
    if (!packingSlipData || !packingSlipData.orderDetails) {
      throw new Error("Invalid packingSlipData: Missing orderDetails");
    }

    // Find order details
    const orderDetails = await Order.findById(
      packingSlipData.orderDetails
    ).session(session); // Ensure this is correct
    if (!orderDetails) {
      throw new Error("Order not found");
    }

    // Extract purchaseOrderNumber and generate packingID
    const purchaseOrderNumber = orderDetails.purchaseOrderNumber;
    if (!purchaseOrderNumber) {
      throw new Error("Purchase Order Number is missing in order details");
    }
    const packingID = `PS${purchaseOrderNumber.slice(2)}`; // Remove 'PO' and prefix with 'PS'

    // Create new packing slip
    const packingSlip = new PackingSlip({
      packingID: packingID,
      orderDetails: orderDetails._id, // Linking to order via ObjectId
      receivedSign: packingSlipData.receivedSign, // Storing image path or data URL
    });

    // Save packing slip
    await packingSlip.save({ session });

    await session.commitTransaction();
    return packingSlip;
  } catch (error) {
    await session.abortTransaction();
    console.error("Error generating packing slip:", error);
    throw error;
  } finally {
    session.endSession();
  }
};

// Service to get all packing slips with formatted date
module.exports.getAllPackingSlips = async () => {
  try {
    // Fetch packing slips and populate required fields
    const packingSlips = await PackingSlip.find({})
      .populate({
        path: "orderDetails", // Populate orderDetails
        populate: {
          path: "products.product", // Populate the `product` field inside the products array
          select: "name ID description", // Select the necessary fields from the product, including `description`
        },
      })
      .select("packingID orderDetails createdAt"); // Ensure createdAt is selected

    // Format the response with the required details
    const formattedPackingSlips = packingSlips.flatMap((slip) => {
      return slip.orderDetails.products.map((item) => ({
        packingSlipID: slip.packingID,
        itemNo: item.product.ID,
        itemName: item.product.name,
        description: item.product.description,
        qty: item.quantity,
        date: slip.createdAt
          ? slip.createdAt.toLocaleDateString("en-GB")
          : "N/A", // Check if createdAt is defined
      }));
    });

    return formattedPackingSlips;
  } catch (error) {
    throw new Error("Failed to fetch packing slips: " + error.message);
  }
};

// Service to get packing slip by packingID
module.exports.getPackingSlipById = async (packingID) => {
  try {
    const packingSlip = await PackingSlip.findOne({ packingID })
      .populate("orderDetails") // Populate the order details
      .select("packingID orderDetails createdAt"); // Select required fields

    if (!packingSlip) {
      throw new Error("Packing slip not found");
    }

    // Format the createdAt date to DD/MM/YYYY
    return {
      packingID: packingSlip.packingID,
      orderDetails: packingSlip.orderDetails,
      createdAt: packingSlip.createdAt.toLocaleDateString("en-GB"), // Format as DD/MM/YYYY
    };
  } catch (error) {
    throw error;
  }
};

module.exports.getPackingSlipByPackingId = async (packingId) => {
  try {
    const data = await PackingSlip.find({ packingID : packingId })
      .populate("orderDetails") 
      .select("packingID orderDetails createdAt");

    if (!data) {
      throw new Error("Packing slip not found");
    }

    return {
      data
    };
  } catch (error) {
    throw error;
  }
};
