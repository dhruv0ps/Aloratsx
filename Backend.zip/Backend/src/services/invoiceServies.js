const mongoose = require("mongoose");
const Invoice = require("../config/models/invoiceModel");
const Order = require("../config/models/orderModel");
const TaxSlab = require("../config/models/taxSlabModel");
const Dealer = require("../config/models/dealerApproved");

module.exports.generateInvoice = async (invoiceData) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    // Find dealer details by ID
    const dealer = await Dealer.findById(invoiceData.dealer);
    if (!dealer) {
      throw new Error("Dealer not found");
    }

    // Retrieve dealer's credit details
    const creditDueDays = parseInt(dealer.creditDueDays) || 30; // Default to 30 days if not provided
    const creditDueAmount = parseFloat(dealer.creditDueAmount) || 1000000; // Default to 1,000,000 if not provided

    // Search for orders related to the dealer in the Order collection
    const orderDetails = await Order.find({ dealer: invoiceData.dealer });
    if (orderDetails.length === 0) {
      throw new Error("No orders found for this dealer");
    }

    // Check if the entered order_id exists in the list of orders for the dealer
    const selectedOrder = orderDetails.find((order) =>
      order._id.equals(invoiceData.orders)
    );
    if (!selectedOrder) {
      throw new Error(
        "Order not found or does not belong to the selected dealer"
      );
    }

    // Retrieve totalAmount from the selected order
    const totalAmount = selectedOrder.grandTotal;

    // Find tax slab details
    const taxSlab = await TaxSlab.findById(invoiceData.taxSlab);
    if (!taxSlab) {
      throw new Error("Tax Slab not found");
    }

    // Get the current date
    const currentDate = new Date();

    // Calculate due date based on dealer's creditDueDays
    let dueDate = new Date(currentDate);
    dueDate.setDate(currentDate.getDate() + creditDueDays);

    // If a custom due date is provided, convert it from DD/MM/YYYY to ISODate
    if (invoiceData.dueDate) {
      const [dd, mm, yyyy] = invoiceData.dueDate.split("/");
      dueDate = new Date(`${yyyy}-${mm}-${dd}`);
    }

    // Determine the invoice status based on the dueAmount and totalAmount
    let invoiceStatus;
    let dueAmount = totalAmount; // Due amount is set to the totalAmount of the order

    if (dueAmount === 0) {
      invoiceStatus = "Paid";
    } else if (dueAmount === totalAmount) {
      invoiceStatus = "Unpaid";
    } else {
      invoiceStatus = "Partially Paid";
    }

    // Generate the invoice number
    const day = String(currentDate.getDate()).padStart(2, "0");
    const month = String(currentDate.getMonth() + 1).padStart(2, "0");
    const year = currentDate.getFullYear();
    const formattedDate = `${day}${month}${year}`;

    // Get the number of invoices already created today
    const invoicesToday = await Invoice.find({
      invoiceString: { $regex: `^${formattedDate}` }, // Search for invoices that start with today's date
    });
    const nextInvoiceNumber = `${formattedDate}${String(
      invoicesToday.length + 1
    ).padStart(3, "0")}`;

    // Create new invoice
    const invoice = new Invoice({
      dealer: dealer._id,
      taxSlab: taxSlab._id,
      orders: selectedOrder._id,
      dueDate: dueDate, // Store date as Date object
      invoiceNumber: nextInvoiceNumber,
      totalAmount: totalAmount.toString(), // Convert to string if required
      dueAmount: dueAmount.toString(), // Convert to string if required
      invoiceStatus: invoiceStatus,
    });

    await invoice.save({ session });
    await session.commitTransaction();
    return invoice;
  } catch (error) {
    await session.abortTransaction();
    throw error;
  } finally {
    session.endSession();
  }
};

module.exports.getAllInvoices = async () => {
  try {
    // Fetch all invoices with specified fields
    const invoices = await Invoice.find({})
      .select(
        "invoiceNumber totalAmount dueAmount dueDate invoiceStatus orders taxSlab"
      )
      .populate({
        path: "orders", // Populate 'orders' field to get order details
        select: "billTo", // Include 'billTo' field from the Order schema
      })
      .populate({
        path: "taxSlab", // Populate 'taxSlab' field to get tax slab details
        select: "name", // Include 'name' field from the TaxSlab schema
      });

    // Map the results to include only the specified fields
    const result = invoices.map((invoice) => {
      const billTo = invoice.orders?.billTo;
      const address = billTo?.address;

      return {
        invoiceID: invoice.invoiceNumber, // Use invoiceNumber as Invoice ID
        builtTo: `${billTo?.companyName}`,
        totalAmount: invoice.totalAmount,
        dueAmount: invoice.dueAmount,
        dueDate: invoice.dueDate.toLocaleDateString("en-GB"), // Format date as DD/MM/YYYY
        status: invoice.invoiceStatus,
        taxSlab: invoice.taxSlab?.name, // Include the name of the tax slab
      };
    });

    return {
      message: "Invoices retrieved successfully",
      invoices: result,
    };
  } catch (error) {
    throw new Error("Failed to fetch invoices: " + error.message);
  }
};

module.exports.getInvoiceById = async (invoiceId) => {
  try {
    // Fetch invoice by ID and populate the orders field
    const invoice = await Invoice.findById(invoiceId);

    if (!invoice) {
      throw new Error("Invoice not found");
    }

    // Return the full invoice details including populated fields
    return invoice;
  } catch (error) {
    throw new Error("Failed to fetch invoice: " + error.message);
  }
};

module.exports.getInvoiceListbyDealer = async (id) => {
  try {
    // Fetch invoices from the database
    const invoices = await Invoice.find({ dealer: id })
      .select("invoiceNumber totalAmount dueAmount dealer");

    // Filter out invoices with dueAmount equal to 0
    const filteredInvoices = invoices.filter(invoice => invoice.dueAmount > 0);

    if (filteredInvoices.length === 0) {
      throw new Error("No invoices with due amount found for this dealer");
    }

    return {
      invoices: filteredInvoices, // Return filtered invoices
    };
  } catch (error) {
    throw new Error("Failed to fetch invoices: " + error.message);
  }
};
