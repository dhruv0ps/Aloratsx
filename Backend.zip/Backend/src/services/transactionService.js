const mongoose = require('mongoose');
const Dealer = require("../config/models/dealerApproved");
const Invoice = require("../config/models/invoiceModel");
const Transaction = require("../config/models/transactionModel");

module.exports.createTransaction = async (transactionData) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    // Find the invoice using the invoiceNumber
    const invoice = await Invoice.findOne({ invoiceNumber: transactionData.invoiceNumber });
    if (!invoice) {
      throw new Error("Invoice not found");
    }
    
    // Check if the invoice is eligible for the transaction (Unpaid or Partially Paid)
    if (invoice.invoiceStatus !== 'Unpaid' && invoice.invoiceStatus !== 'Partially Paid') {
      throw new Error("Invoice not eligible for transaction");
    }

    // Get the dealer from the invoice
    const dealerId = invoice.dealer; // Invoice contains the dealer ID

    // Fetch the dealer details if needed
    const dealer = await Dealer.findById(dealerId);
    if (!dealer) {
      throw new Error("Dealer not found");
    }

    const dueAmount = parseFloat(invoice.dueAmount);
    const captureAmount = parseFloat(transactionData.capturedAmount);

    // Ensure captured amount is not greater than due amount
    if (captureAmount > dueAmount) {
      throw new Error("Captured amount cannot be greater than due amount");
    }

    // Update dueAmount and invoice status
    invoice.dueAmount = dueAmount - captureAmount;

    if (invoice.dueAmount === 0) {
      invoice.invoiceStatus = "Paid"; // Update status to Paid if fully captured
    } else {
      invoice.invoiceStatus = "Partially Paid"; // Otherwise, set status to Partially Paid
    }

    // Save the updated invoice
    await invoice.save({ session });

    // Generate the next transaction ID
    let lastId = 0;
    const lastTransaction = await Transaction.findOne().sort({ createdAt: -1 }).limit(1);
    
    if (lastTransaction) {
      const lastTransactionId = lastTransaction.transactionId;
      lastId = parseInt(lastTransactionId.replace('TXN', '')) || 0;
    }

    const nextId = lastId + 1;
    const transactionId = `TXN${nextId.toString().padStart(3, '0')}`;

    // Create a new transaction record
    const transaction = new Transaction({
      dealer: dealerId,    
      invoiceId: invoice._id,         
      capturedAmount: captureAmount,
      transactionId: transactionId     
    });

    await transaction.save({ session });
    
    await session.commitTransaction();
    return { message: "Transaction created successfully", transaction };
  } catch (error) {
    await session.abortTransaction();
    throw new Error("Failed to create transaction: " + error.message);
  } finally {
    session.endSession();
  }
};

module.exports.getAllTransaction = async () => {
    try {
        // Fetch transactions from the database
        const transactions = await Transaction.find({})
            .populate('dealer', 'contactPersonName')
            .populate('invoiceId', 'invoiceNumber');

        const formattedTransactions = transactions.map(transaction => ({
            dealer: transaction.dealer ? transaction.dealer.contactPersonName : 'N/A',
            invoiceId: transaction.invoiceId ? transaction.invoiceId.invoiceNumber : 'N/A',
            // capturedAmount: transaction.capturedAmount,
            transactionId: transaction.transactionId,
            transactionDate: transaction.createdAt,
        }));

        return formattedTransactions; // Return the formatted transactions directly
    } catch (error) {
        throw new Error("Failed to fetch transactions: " + error.message);
    }
};

module.exports.updateTransaction = async (transactionId, updateData) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    // Find the transaction using the transactionId
    const transaction = await Transaction.findOne({ _id : transactionId });
    if (!transaction) {
      throw new Error("Transaction not found");
    }

    // Validate the new captured amount
    const newCapturedAmount = parseFloat(updateData.capturedAmount);
    if (isNaN(newCapturedAmount) || newCapturedAmount <= 0) {
      throw new Error("Invalid captured amount");
    }

    // Find the associated invoice
    const invoice = await Invoice.findById(transaction.invoiceId);
    if (!invoice) {
      throw new Error("Invoice not found");
    }

    // Ensure the new captured amount does not exceed the invoice's due amount
    const oldCapturedAmount = parseFloat(transaction.capturedAmount);
    const dueAmount = parseFloat(invoice.dueAmount);
    const updatedDueAmount = dueAmount + oldCapturedAmount - newCapturedAmount;

    if (newCapturedAmount > dueAmount + oldCapturedAmount) {
      throw new Error("Captured amount cannot exceed due amount");
    }

    // Update invoice's dueAmount and status if necessary
    invoice.dueAmount = updatedDueAmount;

    if (updatedDueAmount === 0) {
      invoice.invoiceStatus = "Paid";
    } else {
      invoice.invoiceStatus = "Partially Paid";
    }

    await invoice.save({ session });

    // Update the transaction record
    transaction.capturedAmount = newCapturedAmount;
    await transaction.save({ session });

    await session.commitTransaction();
    return { message: "Transaction updated successfully", transaction };
  } catch (error) {
    await session.abortTransaction();
    throw new Error("Failed to update transaction: " + error.message);
  } finally {
    session.endSession();
  }
};

module.exports.deleteTransaction = async (transactionId) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    // Find the transaction using the transactionId
    const transaction = await Transaction.findOne({ transactionId : transactionId });
    if (!transaction) {
      throw new Error("Transaction not found");
    }

    // Find the associated invoice
    const invoice = await Invoice.findById(transaction.invoiceId);
    if (!invoice) {
      throw new Error("Invoice not found");
    }

    // Adjust the invoice's dueAmount and status
    const oldCapturedAmount = parseFloat(transaction.capturedAmount);
    const dueAmount = parseFloat(invoice.dueAmount);
    const updatedDueAmount = dueAmount + oldCapturedAmount;

    // Update invoice's dueAmount and status if necessary
    invoice.dueAmount = updatedDueAmount;

    if (updatedDueAmount === 0) {
      invoice.invoiceStatus = "Paid";
    } else {
      invoice.invoiceStatus = "Partially Paid";
    }

    await invoice.save({ session });

    // Delete the transaction record
    await Transaction.deleteOne({ transactionId }, { session });

    await session.commitTransaction();
    return { message: "Transaction deleted successfully" };
  } catch (error) {
    await session.abortTransaction();
    throw new Error("Failed to delete transaction: " + error.message);
  } finally {
    session.endSession();
  }
};