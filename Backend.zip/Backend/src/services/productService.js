const Product = require("../config/models/ProductModel");
const Category = require("../config/models/categoryModel");
const Color = require("../config/models/colorModel");

const productServices = {
    addProduct: async (productData) => {
        try {
            const product = new Product(productData);
            return await product.save();
        } catch (error) {
            throw error;
        }
    },

    getProductById: async (id) => {
        try {
            return await Product.findById(id).populate('category').populate('children.color');
        } catch (error) {
            throw error;
        }
    },

    getAllProducts: async () => {
        try {
            return await Product.find().populate('category').populate('children.color');
        } catch (error) {
            throw error;
        }
    },
    getAllPagedProducts: async (page = 1, limit = 20, filters = {}) => {
        try {
            const skip = (page - 1) * limit;
            let matchStage = {};

            // Search for ID, product name, child name, and child SKU
            if (filters.search) {
                const searchRegex = new RegExp(filters.search, 'i');
                matchStage.$or = [
                    { 'ID': searchRegex },
                    { 'name': searchRegex },
                    { 'children.SKU': searchRegex },
                    { 'children.name': searchRegex }
                ];
            }

            // Filter by category
            if (filters.category) {
                const matchingCategories = await Category.find({ name: filters.category });
                const categoryIds = matchingCategories.map(ctgry => ctgry._id);
                matchStage.category = { $in: categoryIds };
            }

            // Filter by color
            if (filters.color) {
                const matchingColors = await Color.find({ name: filters.color });
                const colorIds = matchingColors.map(color => color._id);
                matchStage['children.color'] = { $in: colorIds };
            }

            const productlist = await Product.aggregate([
                { $match: matchStage },
                { $unwind: "$children" },
                {
                    $match: {
                        $or: [
                            { 'children.SKU': { $regex: filters.search?.trim() || '', $options: 'i' } },
                            { 'children.name': { $regex: filters.search?.trim() || '', $options: 'i' } },
                            { 'ID': { $regex: filters.search?.trim() || '', $options: 'i' } },
                            { 'name': { $regex: filters.search?.trim() || '', $options: 'i' } }
                        ]
                    }
                },
                {
                    $lookup: {
                        from: 'categories', // the collection name in the database
                        localField: 'category',
                        foreignField: '_id',
                        as: 'category'
                    }
                },
                {
                    $lookup: {
                        from: 'colors', // the collection name in the database
                        localField: 'children.color',
                        foreignField: '_id',
                        as: 'children.color'
                    }
                },
                {
                    $addFields: {
                        category: { $arrayElemAt: ["$category", 0] },
                        'children.color': { $arrayElemAt: ["$children.color", 0] }
                    }
                },
                { $sort: { 'children.createdAt': -1 } },
                { $skip: skip },
                { $limit: limit },
                {
                    $group: {
                        _id: "$_id",
                        ID: { $first: "$ID" },
                        name: { $first: "$name" },
                        category: { $first: "$category" },
                        children: { $push: "$children" }
                    }
                }
            ]);

            // Count the total number of children that match the criteria
            const totalChildren = await Product.aggregate([
                { $match: matchStage },
                { $unwind: "$children" },
                {
                    $match: {
                        $or: [
                            { 'children.SKU': { $regex: filters.search || '', $options: 'i' } },
                            { 'children.name': { $regex: filters.search || '', $options: 'i' } },
                            { 'ID': { $regex: filters.search || '', $options: 'i' } },
                            { 'name': { $regex: filters.search || '', $options: 'i' } }
                        ]
                    }
                },
                { $count: "total" }
            ]);

            const total = totalChildren.length > 0 ? totalChildren[0].total : 0;

            return {
                products: productlist,
                totalPages: Math.ceil(total / limit),
                currentPage: page
            };
        } catch (error) {
            throw error;
        }
    },



    updateProduct: async (id, productData) => {
        try {
            const product = await Product.findById(id);
            if (!product) {
                throw new Error('Product not found');
            }
            const category = await Category.findById(productData.category);
            if (!category) {
                throw new Error("Product category not found.");
            }

            // Update main product fields
            Object.keys(productData).forEach(key => {
                if (key !== 'children') {
                    product[key] = productData[key];
                }
            });

            // Update children
            product.children = await Promise.all(productData.children.map(async (updatedChild) => {
                const color = await Color.findById(updatedChild.color);
                if (!color) {
                    throw new Error(`Color not found for SKU: ${updatedChild.SKU}`);
                }
                return {
                    ...updatedChild,
                    color: color._id
                };
            }));

            return await product.save();
        } catch (error) {
            throw error;
        }
    },

    getPreSaveID: async () => {
        try {
            const highestProduct = await Product.find().sort('-ID').limit(1).exec();

            let nextProductId = 'MAP001';
            if (highestProduct.length > 0) {
                const currentNum = parseInt(highestProduct[0].ID.slice(3));
                nextProductId = `MAP${String(currentNum + 1).padStart(3, '0')}`;
            }
            return nextProductId;
        } catch (error) {
            throw error;
        }
    },
};

module.exports = productServices;