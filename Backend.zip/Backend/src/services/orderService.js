const Order = require('../config/models/orderModel');

const orderService = {
    async createOrder(orderData) {
        try {
            let oid = await orderService.generateOrderId()
            orderData.purchaseOrderNumber = oid
            orderData.product = orderData.parent_id
            // console.log(oid)
            const order = new Order(orderData);
            await order.save();
            return order;
        } catch (error) {
            throw new Error('Failed to create order: ' + error.message);
        }
    },
    generateOrderId: async () => {
        // const today = new Date();
        // const yy = today.getFullYear().toString().slice(-2);
        // const mm = (today.getMonth() + 1).toString().padStart(2, '0');
        // const dd = today.getDate().toString().padStart(2, '0');
        // const datePrefix = `${yy}${mm}${dd}#`;

        // Find the highest order number for this location and date
        const highestOrder = await Order.findOne(
            { sort: { purchaseOrderNumber: -1 } }
        );

        let orderNumber = 1;
        if (highestOrder) {
            orderNumber = parseInt(highestOrder.purchaseOrderNumber.slice(1)) + 1;
        }

        return `#${orderNumber.toString().padStart(2, '0')}`;
    },
    async updateOrder(orderId, updateData) {
        try {
            const order = await Order.findById(orderId);
            if (!order) {
                throw new Error('Order not found');
            }

            if (updateData.phase === "rejected") {
                let del_order = await order.deleteOne()
                return del_order
            }

            order.phase = updateData.phase || order.phase;
            order.status = updateData.status || order.status;

            await order.save();
            return order;
        } catch (error) {
            throw new Error('Failed to update order: ' + error.message);
        }
    },

    async getPendingOrders() {
        try {
            return await Order.find({ phase: 'pending' }).populate("dealer").populate('products.product');
        } catch (error) {
            console.log(error)
            throw new Error('Failed to fetch pending orders: ' + error.message);
        }
    },

    async getApprovedOrders() {
        try {
            return await Order.find({ phase: 'approved' }).populate("dealer").populate('products.product');;
        } catch (error) {
            throw new Error('Failed to fetch approved orders: ' + error.message);
        }
    },

    async getOrderById(orderId) {
        try {
            const order = await Order.findById(orderId).populate('products.product');
            if (!order) {
                throw new Error('Order not found');
            }
            return order;
        } catch (error) {
            throw new Error('Failed to fetch order: ' + error.message);
        }
    },

    async getAllOrderbyDealer(id) {
        try {
            const orders = await Order.find({ dealer: id }).populate('products.product');
            
            // Check if no orders were found
            if (orders.length === 0) {
                throw new Error('No orders found for the specified dealer');
            }
            
            // Extract the required fields from each order and its products
            const result = orders.map(order => ({
                id: order._id, // Add order ID to the result
                products: order.products.map(product => ({
                    name: product.product.name,
                    price: product.price,
                    quantity: product.quantity,
                })),
            }));
            
            return result;
        } catch (error) {
            throw new Error('Failed to fetch orders: ' + error.message);
        }
    },

    async getOrderbyPOnumber(OrderNumber) {
        try {
          const order = await Order.findOne({ purchaseOrderNumber : OrderNumber })
      
          if (!order) {
            throw new Error("order not found");
          }
      
          return order
        } catch (error) {
          throw error;
        }
      }
};

module.exports = orderService;
