import React, { useState } from 'react';
import { toast } from 'react-toastify';
import Loading from '../../util/Loading';
import { useNavigate } from 'react-router-dom';
import { Button } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { Address } from '../../config/models/address';
import { DealerForm } from '../../config/models/dealer';
import { dealerApis } from '../../config/apiRoutes/dealerRoutes';
import AutoCompleteAddress from '../../util/AutoCompleteGoogle';

const AddDealer: React.FC = () => {
    const [formState, setFormState] = useState<DealerForm>({
        username: '',
        email: '',
        mobile: '',
        designation: '',
        province: '',
        company: '',
        address: { longitude: "", latitude: "", address: "" },
    });

    const [loading, setLoading] = useState<boolean>(false);
    const navigate = useNavigate();

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        if (name === 'mobile' && isNaN(Number(value))) return;

        setFormState((prev: DealerForm) => {
            if (name === 'unit' || name === 'buzz') {
                return {
                    ...prev,
                    address: {
                        ...prev.address!,
                        [name]: value,
                    },
                };
            } else {
                return {
                    ...prev,
                    [name]: value,
                };
            }
        });
    };


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formState.address?.address || !formState.address?.longitude || !formState.address?.latitude) {
            toast.error('Please select a valid address');
            return;
        }
        setLoading(true);
        try {
            let res = await dealerApis.createTempDealer(formState);
            if (res.status) {
                // localStorage.setItem('token', res.data)
                toast.success('New dealer added successfully');
                navigate('/dealers');
            } else {
                toast.error(res.err);
            }
        } catch (error: any) {
            // toast.error(error.response?.data?.err || 'An error occurred');
            console.log(error)
        } finally {
            setLoading(false);
        }
    };

    const handleAddressChange = (address: Address) => {
        setFormState(prev => ({
            ...prev,
            address: {
                ...prev.address,
                ...address,
            },
        }));
    };

    return (
        loading ? <Loading /> : (
            <form onSubmit={handleSubmit} className="max-w-4xl mx-auto bg-white p-8 rounded-lg">
                <div className="flex items-center mb-12 justify-between">
                    <Button className='' color={'gray'} onClick={() => navigate(-1)}>
                        <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                    </Button>
                    <h2 className="text-2xl font-semibold">Dealer Onboard</h2>
                    <p></p>
                </div>

                <div className="mb-4">
                    <label htmlFor="username" className="block text-sm font-medium text-gray-700 mb-2">* Name:</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={formState.username}
                        onChange={handleInputChange}
                        required
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200"
                    />
                </div>

                <div className="mb-4">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">* Email:</label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        value={formState.email}
                        onChange={handleInputChange}
                        required
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200"
                    />
                </div>

                <div className="mb-4">
                    <label htmlFor="mobile" className="block text-sm font-medium text-gray-700 mb-2">* Mobile:</label>
                    <input
                        type="tel"
                        id="mobile"
                        name="mobile"
                        value={formState.mobile}
                        onChange={handleInputChange}
                        required
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200"
                    />
                </div>

                <div className="mb-4">
                    <label htmlFor="designation" className="block text-sm font-medium text-gray-700 mb-2">* Designation:</label>
                    <input
                        type="text"
                        id="designation"
                        name="designation"
                        value={formState.designation}
                        onChange={handleInputChange}
                        required
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200"
                    />
                </div>

                <div className="mb-4">
                    <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-2">* Company:</label>
                    <input
                        type="text"
                        id="company"
                        name="company"
                        value={formState.company}
                        onChange={handleInputChange}
                        required
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200"
                    />
                </div>

                <div className="mb-4">
                    <label htmlFor="province" className="block text-sm font-medium text-gray-700 mb-2">* Province:</label>
                    <input
                        type="text"
                        id="province"
                        name="province"
                        value={formState.province}
                        onChange={handleInputChange}
                        required
                        className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200"
                    />
                </div>

                <div className="mb-4 space-y-2">
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-2">Address:</label>
                    <div className="flex gap-x-5 items-center w-full">
                        <input
                            className='flex-[0.5] w-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200'
                            name="unit"
                            placeholder='Unit'
                            value={formState.address?.unit || ''}
                            onChange={handleInputChange}
                        />
                        <input
                            className='flex-[0.5] w-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200'
                            name="buzz"
                            placeholder='Buzz Code'
                            value={formState.address?.buzz || ''}
                            onChange={handleInputChange}
                        />
                    </div>
                    <AutoCompleteAddress onChange={handleAddressChange} />
                    {formState.address?.address ? (
                        <p className='text-xs text-gray-500 my-2'>
                            <b>Selected address :</b> {formState.address.address}
                        </p>
                    ) : null}
                </div>

                <button type="submit" className="w-full py-2 px-4 bg-indigo-600 text-white font-semibold rounded-md shadow hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    Create Dealer
                </button>
            </form>
        )
    );
};

export default AddDealer;
