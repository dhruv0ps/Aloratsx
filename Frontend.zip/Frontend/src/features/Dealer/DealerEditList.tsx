import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { taxSlab } from '../../config/models/taxslab';
import { Dealer, FormDataApprovedDealer } from '../../config/models/dealer';
import { commonApis } from '../../config/apiRoutes/commonRoutes';
import { dealerApis } from '../../config/apiRoutes/dealerRoutes';
import { toast } from 'react-toastify';
import Loading from '../../util/Loading';
import AutoCompleteAddress from '../../util/AutoCompleteGoogle';
import { Address } from '../../config/models/address';
import { Button } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { HiEye, HiEyeOff } from 'react-icons/hi';

interface FormErrors {
    [key: string]: string;
}

const DealerEditList: React.FC = () => {
    const { id, aid } = useParams<{ id?: string; aid?: string }>();
    const [formData, setFormData] = useState<FormDataApprovedDealer>({
        contactPersonName: '',
        contactPersonCell: '',
        contactPersonEmail: '',
        designation: '',
        companyName: '',
        address: {
            address: "",
            longitude: "",
            latitude: ""
        },
        province: '',
        priceDiscount: 0,
        emailId: '',
        password: '',
        creditDueDays: 0,
        creditDueAmount: 0,
    });
    const [showPassword, setShowPassword] = useState(false);
    const [errors, setErrors] = useState<FormErrors>({});
    const [taxSlabs, setTaxSlabs] = useState<taxSlab[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    // const [error, setError] = useState<string | null>(null);
    const navigate = useNavigate()

    useEffect(() => {
        const fetchTaxSlabs = async () => {
            setLoading(true)
            try {
                const response = await commonApis.getAllTaxSlabs()
                setTaxSlabs(response.data);
            } catch (err) {
                // setError('Failed to fetch tax slabs');
            } finally {
                setLoading(false)
            }
        };

        fetchTaxSlabs();
    }, []);

    useEffect(() => {
        const fetchDealerDetails = async () => {
            setLoading(true)
            try {
                if (aid) {
                    const response = await dealerApis.getApprovedDealerbyId(aid)
                    setFormData(response.data);
                } else if (id) {
                    const response = await dealerApis.getTempDealerbyId(id)
                    let data: Dealer = response.data
                    setFormData(prev => ({
                        ...prev, contactPersonName: data.username,
                        contactPersonCell: data.mobile,
                        province: data.province._id ?? "",
                        emailId: data.email,
                        contactPersonEmail: data.email,
                        address: data.address,
                        designation: data.designation,
                        companyName: data.company
                    }));
                }
            } catch (err) {
                // setError('Failed to fetch dealer details');
            } finally {
                setLoading(false)
            }
        };

        if (id || aid) {
            fetchDealerDetails();
        }
    }, [id, aid]);

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;

        // Prevent excessive length for specific fields
        if (
            [
                'contactPersonName',
                'contactPersonCell',
                'contactPersonEmail',
                'designation',
                'companyName',
                'priceDiscount',
                'emailId',
                'password',
                'creditDueDays',
                'creditDueAmount',
            ].includes(name) &&
            value.length > 24
        ) {
            return; // Prevent input if it exceeds 24 characters
        }

        // Prevent negative values for specific fields
        if ((name === 'creditDueAmount' || name === 'priceDiscount' || name === 'creditDueDays') && Number(value) < 0) {
            return; // Prevent negative input
        }

        setFormData(prev => {
            if (name === 'unit' || name === 'buzz') {
                return {
                    ...prev,
                    address: {
                        ...prev.address!,
                        [name]: value,
                    },
                };
            } else {
                return {
                    ...prev,
                    [name]: value,
                };
            }
        });
    };

    const handleAddressChange = (address: Address) => {
        setFormData(prev => ({
            ...prev,
            address: {
                ...prev.address,
                ...address,
            },
        }));
    };

    const validateForm = (): FormErrors => {
        const newErrors: FormErrors = {};
        // Validation logic
        if (!formData.contactPersonName) newErrors.contactPersonName = 'Contact Person Name is required';
        if (!formData.contactPersonCell) newErrors.contactPersonCell = 'Contact Person Cell is required';
        if (!formData.contactPersonEmail) {
            newErrors.contactPersonEmail = 'Contact Person Email ID is required';
        } else if (!/\S+@\S+\.\S+/.test(formData.contactPersonEmail)) {
            newErrors.contactPersonEmail = 'Email must be a valid email address';
        }
        // Other validation logic...
        return newErrors;
    };

    const handleSaveEdits = async () => {
        const validationErrors = validateForm();
        if (Object.keys(validationErrors).length > 0) {
            setErrors(validationErrors);
            return;
        }
        // console.log(formData)
        if (id) {
            const res = await dealerApis.createApprovedDealer({ ...formData, tempid: id })
            if (res.status) {
                toast.success("Successfully approved dealer application.")
            }
        } else if (aid) {
            const res = await dealerApis.updateApprovedDealer(aid, formData)
            if (res.status) {
                toast.success("Successfully updated dealer details.")
            }
        }
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold ">Edit Dealer Details</h2>
                <p></p>
            </div>
            {loading ? <Loading /> : <div className="bg-white p-6 rounded-lg shadow-md border-t-4 border-gray-300 mt-12">
                <form>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Province field */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="province">
                                Select Province
                            </label>
                            <select
                                id="province"
                                name="province"
                                value={formData.province}
                                onChange={handleChange}
                                className={`w-full border ${errors.province ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                required
                            >
                                <option value="">Select a province</option>
                                {taxSlabs.map((slab) => (
                                    <option key={slab._id} value={slab._id}>
                                        {slab.name}
                                    </option>
                                ))}
                            </select>
                            {errors.province && <p className="text-red-500 text-sm">{errors.province}</p>}
                        </div>

                        {/* Contact Person Name */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="contactPersonName">
                                Contact Person Name
                            </label>
                            <input
                                type="text"
                                id="contactPersonName"
                                name="contactPersonName"
                                value={formData.contactPersonName}
                                onChange={handleChange}
                                className={`w-full border ${errors.contactPersonName ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                maxLength={24}
                            />
                            {errors.contactPersonName && <p className="text-red-500 text-sm">{errors.contactPersonName}</p>}
                        </div>

                        {/* Contact Person Cell */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="contactPersonCell">
                                Contact Person Cell
                            </label>
                            <input
                                type="text"
                                id="contactPersonCell"
                                name="contactPersonCell"
                                value={formData.contactPersonCell}
                                onChange={handleChange}
                                className={`w-full border ${errors.contactPersonCell ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                maxLength={24}
                            />
                            {errors.contactPersonCell && <p className="text-red-500 text-sm">{errors.contactPersonCell}</p>}
                        </div>

                        {/* Contact Person Email */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="contactPersonEmail">
                                Contact Person Email
                            </label>
                            <input
                                type="email"
                                id="contactPersonEmail"
                                name="contactPersonEmail"
                                value={formData.contactPersonEmail}
                                onChange={handleChange}
                                className={`w-full border ${errors.contactPersonEmail ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                maxLength={24}
                            />
                            {errors.contactPersonEmail && <p className="text-red-500 text-sm">{errors.contactPersonEmail}</p>}
                        </div>

                        {/* Designation */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="designation">
                                Designation
                            </label>
                            <input
                                type="text"
                                id="designation"
                                name="designation"
                                value={formData.designation}
                                onChange={handleChange}
                                className={`w-full border ${errors.designation ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                maxLength={24}
                            />
                            {errors.designation && <p className="text-red-500 text-sm">{errors.designation}</p>}
                        </div>

                        {/* Company Name */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="companyName">
                                Company Name
                            </label>
                            <input
                                type="text"
                                id="companyName"
                                name="companyName"
                                value={formData.companyName}
                                onChange={handleChange}
                                className={`w-full border ${errors.companyName ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                maxLength={24}
                            />
                            {errors.companyName && <p className="text-red-500 text-sm">{errors.companyName}</p>}
                        </div>
                        <div className="mb-4 space-y-2">
                            <label htmlFor="address" className="block text-sm font-medium text-gray-700 mb-2">Address:</label>
                            <div className="flex gap-x-5 items-center w-full">
                                <input
                                    className='flex-[0.5] w-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200'
                                    name="unit"
                                    placeholder='Unit'
                                    value={formData.address?.unit || ''}
                                    onChange={handleChange}
                                />
                                <input
                                    className='flex-[0.5] w-32 px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring focus:ring-indigo-200'
                                    name="buzz"
                                    placeholder='Buzz Code'
                                    value={formData.address?.buzz || ''}
                                    onChange={handleChange}
                                />
                            </div>
                            <AutoCompleteAddress onChange={handleAddressChange} />
                            {formData.address?.address ? (
                                <p className='text-xs text-gray-500 my-2'>
                                    <b>Selected address :</b> {formData.address.address}
                                </p>
                            ) : null}
                        </div>
                        {/* Price Discount */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="priceDiscount">
                                Price Discount
                            </label>
                            <input
                                type="number"
                                id="priceDiscount"
                                name="priceDiscount"
                                value={formData.priceDiscount}
                                onChange={handleChange}
                                className={`w-full border ${errors.priceDiscount ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                min={0}
                            />
                            {errors.priceDiscount && <p className="text-red-500 text-sm">{errors.priceDiscount}</p>}
                        </div>

                        {/* Email ID */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="emailId">
                                Email ID
                            </label>
                            <input
                                type="email"
                                id="emailId"
                                name="emailId"
                                value={formData.emailId}
                                onChange={handleChange}
                                className={`w-full border ${errors.emailId ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                            />
                            {errors.emailId && <p className="text-red-500 text-sm">{errors.emailId}</p>}
                        </div>

                        {/* Password */}
                        <div className="mb-4 relative">
                            <label className="block text-sm font-medium mb-2" htmlFor="password">
                                Password
                            </label>
                            <div className="relative">
                                <input
                                    type={showPassword ? 'text' : 'password'}
                                    id="password"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleChange}
                                    className={`w-full border ${errors.password ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2 pr-10`}
                                    minLength={8}
                                />
                                <div
                                    className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                                    onClick={togglePasswordVisibility}
                                >
                                    {showPassword ? <HiEyeOff className="text-gray-500" /> : <HiEye className="text-gray-500" />}
                                </div>
                            </div>
                            {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}
                        </div>

                        {/* Credit Due Days */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="creditDueDays">
                                Credit Due Days
                            </label>
                            <input
                                type="number"
                                id="creditDueDays"
                                name="creditDueDays"
                                value={formData.creditDueDays}
                                onChange={handleChange}
                                className={`w-full border ${errors.creditDueDays ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                min={0}
                            />
                            {errors.creditDueDays && <p className="text-red-500 text-sm">{errors.creditDueDays}</p>}
                        </div>

                        {/* Credit Due Amount */}
                        <div className="mb-4">
                            <label className="block text-sm font-medium mb-2" htmlFor="creditDueAmount">
                                Credit Due Amount
                            </label>
                            <input
                                type="number"
                                id="creditDueAmount"
                                name="creditDueAmount"
                                value={formData.creditDueAmount}
                                onChange={handleChange}
                                className={`w-full border ${errors.creditDueAmount ? 'border-red-500' : 'border-gray-300'} rounded-lg p-2`}
                                min={0}
                            />
                            {errors.creditDueAmount && <p className="text-red-500 text-sm">{errors.creditDueAmount}</p>}
                        </div>

                        {/* Save Button */}
                        <div className="col-span-2">
                            <button
                                type="button"
                                onClick={handleSaveEdits}
                                className="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600"
                            >
                                SAVE EDITS
                            </button>
                        </div>
                    </div>
                </form>

            </div>}
        </div>
    );
};

export default DealerEditList;
