import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { Button, TextInput } from 'flowbite-react';
import { useNavigate, useParams } from 'react-router-dom';
import { orderApis } from '../../config/apiRoutes/orderRoutes';
import Loading from '../../util/Loading';
import { FaChevronLeft } from 'react-icons/fa';
import { MdDelete } from 'react-icons/md';
import AutoCompleteAddress from '../../util/AutoCompleteGoogle';
import { Address } from '../../config/models/address';
import AutoCompleteDealerInput from '../../util/AutoCompleteDealer';
import AutocompleteProductInput from '../../util/AutoCompleteProductInput';
import { OrderFormState } from '../../config/models/order';
import { ApprovedDealer } from '../../config/models/dealer';
import { Child } from '../../config/models/Child';
import showConfirmationModal from '../../util/confirmationUtil';

const OrderForm = () => {
    const { id } = useParams<{ id: string }>();
    const [formState, setFormState] = useState<OrderFormState>({
        dealer: '',
        purchaseOrderNumber: '',
        date: new Date().toISOString().split("T")[0],
        billTo: {
            companyName: '',
            address: { address: '', longitude: '', latitude: '' }
        },
        shipTo: {
            companyName: '',
            address: { address: '', longitude: '', latitude: '' }
        },
        products: [],
        totalBeforeTax: 0,
        gst: 0,
        hst: 0,
        transportation: 0,
        grandTotal: 0,
    });
    const [selectedDealer, setSelectedDealer] = useState<ApprovedDealer>()
    const [loading, setLoading] = useState<boolean>(false);
    const [inputValue, setInputValue] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        calculateTotals();
    }, [formState.products, formState.transportation]);

    // const fetchOrderDetails = async () => {
    //     try {
    //         setLoading(true);
    //         const response = await orderApis.getOrderByID(id);
    //         if (response.status) {
    //             setFormState(response.data);
    //         }
    //     } catch (error: any) {
    //         toast.error(error.response.data.err ?? "Something went wrong.");
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        let { name, value } = e.target;
        if (name === 'date')
            value = new Date(value).toISOString().split("T")[0]
        setFormState(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleAddressChange = (address: Address, type: 'billTo' | 'shipTo') => {
        setFormState(prevState => ({
            ...prevState,
            [type]: {
                ...prevState[type],
                address
            }
        }));
    };

    const handleDealerChange = async (dealer: ApprovedDealer) => {
        if (formState.products.length > 0) {
            const confirmed = await showConfirmationModal("Selecting a new dealer will result in emptying the current cart. Are you sure u want to proceed?")
            if (!confirmed)
                return
        }
        setFormState(prevState => ({
            ...prevState,
            dealer: dealer._id,
            billTo: {
                companyName: dealer.companyName,
                address: dealer.address
            },
            products: []
        }));
        setSelectedDealer(dealer)
    };
    const handleShippingMode = () => {
        setFormState(prevState => ({
            ...prevState,
            shipTo: prevState.billTo
        }));
    };

    const handleProductChange = (product: Child & { parentName: string, parent_id: string }) => {
        // console.log(product)
        let discount = 0
        if (selectedDealer)
            discount = selectedDealer.priceDiscount
        const newPrice = Number(product.selling_price) * Number(discount) / 100
        // console.log(newPrice)
        setFormState(prevState => ({
            ...prevState,
            products: [
                ...prevState.products,
                {
                    parent_id: product.parent_id,
                    parentName: product.parentName,
                    product: product.parent_id,
                    childSKU: product.SKU,
                    quantity: 1,
                    price: product.selling_price - newPrice
                }
            ]
        }));
        setInputValue('');
    };

    const handleQuantityChange = (index: number, quantity: number) => {
        setFormState(prevState => ({
            ...prevState,
            products: prevState.products.map((product, i) =>
                i === index ? { ...product, quantity } : product
            )
        }));
    };
    const setUnitPriceChange = (index: number, price: number) => {
        setFormState(prevState => ({
            ...prevState,
            products: prevState.products.map((product, i) =>
                i === index ? { ...product, price } : product
            )
        }));
    };


    const handleRemoveProduct = (index: number) => {
        setFormState(prevState => ({
            ...prevState,
            products: prevState.products.filter((_, i) => i !== index)
        }));
    };

    const calculateTotals = () => {
        const totalBeforeTax = formState.products.reduce((acc, product) => acc + Number(product.price * product.quantity), 0);
        let hst = 0, gst = 0
        if (selectedDealer) {
            hst = totalBeforeTax * selectedDealer.province.hst / 100
            gst = totalBeforeTax * selectedDealer.province.gst / 100
        }
        const grandTotal = totalBeforeTax + hst + gst + formState.transportation;

        setFormState(prevState => ({
            ...prevState,
            totalBeforeTax,
            gst,
            hst,
            grandTotal
        }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (formState.products.length < 1) {
            toast.info("Please add products first.");
            return;
        }
        setLoading(true);
        try {
            let res;
            if (id) {
                res = await orderApis.updateOrder(id, formState);
            } else {
                res = await orderApis.createOrderRequest(formState);
            }
            if (res.status) {
                toast.success(`Order successfully ${id ? 'updated' : 'created'}.`);
                navigate(`/orders/view/${res.data._id}`);
            }
        } catch (error: any) {
            toast.error(error.response.data.err ?? "Something went wrong.");
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <Loading />;

    return (
        <form className="max-w-4xl mx-auto bg-white p-8 shadow-md rounded-lg" onSubmit={handleSubmit}>
            <div className="flex mb-8 justify-between items-center">
                <Button className='' color={'gray'} onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold">{id ? 'Edit Order' : 'Create Order'}</h2>
            </div>

            <div className="flex gap-x-5 justify-between">
                <div className="mb-4 flex-grow">
                    <label htmlFor="dealer" className="block text-sm font-medium text-gray-700 mb-2">Dealer:</label>
                    <AutoCompleteDealerInput value={formState.dealer} onChange={handleDealerChange} />
                </div>
                <div className="mb-4 flex-grow">
                    <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">Date:</label>
                    <TextInput
                        type="date"
                        id="date"
                        name="date"
                        value={formState.date}
                        onChange={handleInputChange}
                        required
                    />
                </div>
            </div>
            {/* 
            <div className="mb-4">
                <label htmlFor="purchaseOrderNumber" className="block text-sm font-medium text-gray-700 mb-2">Purchase Order Number:</label>
                <TextInput
                    id="purchaseOrderNumber"
                    name="purchaseOrderNumber"
                    value={formState.purchaseOrderNumber}
                    onChange={handleInputChange}
                    required
                />
            </div> */}



            <div className="mb-4">
                <h3 className="block text-sm font-medium text-gray-700 mb-2">Bill To:</h3>
                <TextInput
                    className="mb-2"
                    placeholder="Company Name"
                    value={formState.billTo.companyName}
                    onChange={(e) => setFormState(prevState => ({
                        ...prevState,
                        billTo: { ...prevState.billTo, companyName: e.target.value }
                    }))}
                    required
                />
                <AutoCompleteAddress onChange={(address) => handleAddressChange(address, 'billTo')} />
                {formState.billTo.address.address ? <p className='text-xs text-gray-500 my-2'><b>Selected address :</b> {formState.billTo.address.address}</p> : <></>}
            </div>

            <div className="mb-4">
                <h3 className="block text-sm font-medium text-gray-700 mb-2">Ship To<span className='text-xs ml-1 border-blue-500 pb-1 cursor-pointer text-blue-500 border-b-dotted' onClick={() => handleShippingMode()}>(Same as Billing?):</span></h3>
                <TextInput
                    className="mb-2"
                    placeholder="Company Name"
                    value={formState.shipTo.companyName}
                    onChange={(e) => setFormState(prevState => ({
                        ...prevState,
                        shipTo: { ...prevState.shipTo, companyName: e.target.value }
                    }))}
                />
                <AutoCompleteAddress onChange={(address) => handleAddressChange(address, 'shipTo')} />
                {formState.shipTo.address.address ? <p className='text-xs text-gray-500 my-2'><b>Selected address :</b> {formState.shipTo.address.address}</p> : <></>}
            </div>

            <div className="mb-4">
                <label htmlFor="productsInput" className="block text-sm font-medium text-gray-700 mb-2">Add Products:</label>
                <AutocompleteProductInput value={inputValue} onChange={handleProductChange} setInputValue={setInputValue} />
            </div>

            {formState.products.length > 0 && (
                <table className="min-w-full divide-y my-8 divide-gray-200">
                    <thead>
                        <tr>
                            <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                            <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">SKU</th>
                            <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unit Price</th>
                            <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                            <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                            <th className="px-2 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {formState.products.map((product, index) => (
                            <tr key={index} className='text-sm'>
                                <td className="px-2 py-4 whitespace-nowrap">{product.parentName}</td>
                                <td className="px-2 py-4 whitespace-nowrap">{product.childSKU}</td>
                                <td className="px-2 py-4 whitespace-nowrap">
                                    <input
                                        type="number"
                                        value={product.price}
                                        onChange={(e) => setUnitPriceChange(index, Number(e.target.value))}
                                        className="w-24 border-gray-300 rounded-md shadow-sm"
                                        min={0}
                                        step="0.01"
                                    />
                                </td>
                                <td className="px-2 py-4 whitespace-nowrap">
                                    <input
                                        type="number"
                                        value={product.quantity}
                                        onChange={(e) => handleQuantityChange(index, Number(e.target.value))}
                                        className="w-16 border-gray-300 rounded-md shadow-sm"
                                        min={1}
                                    />
                                </td>
                                <td className="px-2 py-4 whitespace-nowrap">${(product.price * product.quantity).toFixed(2)}</td>
                                <td className="px-2 py-4 whitespace-nowrap">
                                    <button type="button" onClick={() => handleRemoveProduct(index)} className="text-red-600 hover:text-red-800">
                                        <MdDelete className='ml-5' />
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}

            <div className="mb-4">
                <label htmlFor="transportation" className="block text-sm font-medium text-gray-700 mb-2">Transportation Cost:</label>
                <TextInput
                    type="number"
                    id="transportation"
                    name="transportation"
                    value={formState.transportation}
                    onChange={handleInputChange}
                    min={0}
                />
            </div>

            <div className="mb-4">
                <label htmlFor="totalBeforeTax" className="block text-sm font-medium text-gray-700 mb-2">Total Before Tax:</label>
                <TextInput
                    type="number"
                    id="totalBeforeTax"
                    value={formState.totalBeforeTax.toFixed(2)}
                    readOnly
                />
            </div>

            <div className="flex gap-x-5 justify-between">
                <div className="mb-4 flex-grow">
                    <label htmlFor="gst" className="block text-sm font-medium text-gray-700 mb-2">GST ({selectedDealer?.province?.gst}%):</label>
                    <TextInput
                        type="number"
                        id="gst"
                        value={formState.gst.toFixed(2)}
                        readOnly
                    />
                </div>
                <div className="mb-4 flex-grow">
                    <label htmlFor="hst" className="block text-sm font-medium text-gray-700 mb-2">HST ({selectedDealer?.province?.hst}%):</label>
                    <TextInput
                        type="number"
                        id="hst"
                        value={formState.hst.toFixed(2)}
                        readOnly
                    />
                </div>
            </div>

            <div className="mb-4">
                <label htmlFor="grandTotal" className="block text-sm font-medium text-gray-700 mb-2">Grand Total:</label>
                <TextInput
                    type="number"
                    id="grandTotal"
                    value={formState.grandTotal?.toFixed(2)}
                    readOnly
                />
            </div>

            {/* <div className="mb-4">
                <label htmlFor="phase" className="block text-sm font-medium text-gray-700 mb-2">Phase:</label>
                <Select
                    id="phase"
                    name="phase"
                    value={formState.phase}
                    onChange={handleInputChange}
                >
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                </Select>
            </div> */}

            {/* <div className="mb-4">
                <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2">Status:</label>
                <Select
                    id="status"
                    name="status"
                    value={formState.status}
                    onChange={handleInputChange}
                >
                    <option value="APPROVED">APPROVED</option>
                    <option value="READY">READY</option>
                    <option value="REJECT">REJECT</option>
                    <option value="SHIPPED">SHIPPED</option>
                    <option value="FULFILLED">FULFILLED</option>
                </Select>
            </div> */}

            {/* <div className="mb-4">
                <label htmlFor="invoiceStatus" className="block text-sm font-medium text-gray-700 mb-2">Invoice Status:</label>
                <Select
                    id="invoiceStatus"
                    name="invoiceStatus"
                    value={formState.invoiceStatus}
                    onChange={handleInputChange}
                >
                    <option value="Pending">Pending</option>
                    <option value="Invoiced">Invoiced</option>
                </Select>
            </div> */}

            <button
                type="submit"
                className="w-full cursor-pointer bg-indigo-600 text-white p-2 rounded-md hover:bg-indigo-700"
            >
                {id ? 'Update Order' : 'Create Order Request'}
            </button>
        </form>
    );
};

export default OrderForm;