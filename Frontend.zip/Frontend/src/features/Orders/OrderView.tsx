import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Table, Button, TextInput, Select, Modal } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { toast } from 'react-toastify';
import Loading from '../../util/Loading'; // Adjust the import path as needed
import { orderApis } from '../../config/apiRoutes/orderRoutes'; // Adjust the import path as needed
import { OrderWithData } from '../../config/models/order'; // Adjust the import path as needed

const Orders: React.FC = () => {
    const [orders, setOrders] = useState<OrderWithData[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [sortOption, setSortOption] = useState<'recent' | 'az' | 'za'>('recent');
    const [selectedOrder, setSelectedOrder] = useState<OrderWithData | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        setLoading(true);
        try {
            const response = await orderApis.getAllApprovedOrders();
            if (response.status) {
                setOrders(response.data);
            }
        } catch (error) {
            console.error('Failed to fetch orders', error);
            toast.error('Failed to load orders');
        } finally {
            setLoading(false);
        }
    };

    const sortedOrders = [...orders]
        .filter((order) =>
            order.dealer.contactPersonName.toLowerCase().includes(searchTerm?.toLowerCase()) ||
            order.purchaseOrderNumber.includes(searchTerm?.toLowerCase())
        )
        .sort((a, b) => {
            if (sortOption === 'recent') {
                return new Date(b.date).getTime() - new Date(a.date).getTime();
            } else if (sortOption === 'az') {
                return a.dealer.contactPersonName.localeCompare(b.dealer.contactPersonName);
            } else {
                return b.dealer.contactPersonName.localeCompare(a.dealer.contactPersonName);
            }
        });

    const handleDelete = async (id: string) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this order?');
        if (confirmDelete) {
            try {
                await orderApis.updateOrder(id, { status: "DELETED" });
                toast.success('Order deleted successfully');
                fetchOrders(); // Refresh the list
            } catch (error) {
                console.error('Failed to delete order', error);
                toast.error('Failed to delete order');
            }
        }
    };

    const viewOrder = (orderId: string) => {
        navigate(`/purchaseorder/${orderId}`);
    };

    const printOrder = () => {
        toast.info("Coming soon")
    };

    const openModal = (order: OrderWithData) => {
        setSelectedOrder(order);
        setIsModalOpen(true);
    };

    if (loading) return <Loading />;

    return (
        <div className="mx-auto p-4 lg:px-8">
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold flex-grow text-center">Order List</h2>
            </div>
            <div className='flex gap-6 justify-between items-center mb-6'>
                <TextInput
                    type="text"
                    placeholder="Search by dealer name or order ID"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex-1"
                />
                <Select
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value as 'recent' | 'az' | 'za')}
                    className="ml-2"
                >
                    <option value="recent">Sort by Recent Date</option>
                    <option value="az">Sort A-Z</option>
                    <option value="za">Sort Z-A</option>
                </Select>
            </div>
            <div className="overflow-x-auto">
                <Table>
                    <Table.Head>
                        <Table.HeadCell>Order ID</Table.HeadCell>
                        <Table.HeadCell>Dealer Name</Table.HeadCell>
                        <Table.HeadCell>Dealer Company Name</Table.HeadCell>
                        <Table.HeadCell>Status</Table.HeadCell>
                        <Table.HeadCell>Created At</Table.HeadCell>
                        <Table.HeadCell className='text-center'>Action</Table.HeadCell>
                    </Table.Head>
                    <Table.Body className="divide-y">
                        {sortedOrders.map((order) => (
                            <Table.Row key={order._id}
                                className="bg-white hover:bg-gray-100 cursor-pointer"
                                onClick={() => openModal(order)}>
                                <Table.Cell className="whitespace-nowrap font-medium text-gray-900">{order.purchaseOrderNumber}</Table.Cell>
                                <Table.Cell>{order.dealer.contactPersonName}</Table.Cell>
                                <Table.Cell>{order.dealer.companyName}</Table.Cell>
                                <Table.Cell>
                                    <span
                                        className={`px-2 py-1 rounded-full text-xs font-medium ${order.status === 'REJECTED'
                                            ? 'bg-yellow-100 text-yellow-600'
                                            : order.status === 'APPROVED'
                                                ? 'bg-green-100 text-green-600'
                                                : 'bg-red-100 text-red-600'
                                            }`}
                                    >
                                        {order.status}
                                    </span>
                                </Table.Cell>
                                <Table.Cell>{new Date(order.date).toLocaleDateString()}</Table.Cell>
                                <Table.Cell>
                                    <div className="flex justify-center space-x-2">
                                        <Button
                                            color={'purple'}
                                            onClick={() => viewOrder(order._id)}

                                        >
                                            View
                                        </Button>
                                        <Button
                                            color={'failure'}
                                            onClick={() => handleDelete(order._id)}

                                        >
                                            Delete
                                        </Button>
                                        <Button
                                            color={'warning'}
                                            onClick={() => printOrder()}

                                        >
                                            Print
                                        </Button>
                                    </div>
                                </Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </div>

            <Modal show={isModalOpen} onClose={() => setIsModalOpen(false)} size="xl">
                <Modal.Header>
                    Order Details
                </Modal.Header>
                <Modal.Body>
                    {selectedOrder && (
                        <div className="space-y-4">
                            <div>
                                <h3 className="text-lg font-semibold">Dealer Information</h3>
                                <p>Name: {selectedOrder.dealer.contactPersonName}</p>
                                <p>Company: {selectedOrder.dealer.companyName}</p>
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold">Order Information</h3>
                                <p>PO Number: {selectedOrder.purchaseOrderNumber}</p>
                                <p>Date: {new Date(selectedOrder.date).toLocaleDateString()}</p>
                                <p>Grand Total: ${selectedOrder.grandTotal.toFixed(2)}</p>
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold">Products</h3>
                                <ul className="list-disc pl-5">
                                    {selectedOrder.products.map((product, index) => (
                                        <li key={index}>
                                            {product.product.name} - Quantity: {product.quantity}, Price: ${product.price.toFixed(2)}
                                        </li>
                                    ))}
                                </ul>
                            </div>
                            <div>
                                <h3 className="text-lg font-semibold">Billing Address</h3>
                                <p>{selectedOrder.billTo.companyName}</p>
                                <p>{selectedOrder.billTo.address.address}</p>
                            </div>
                        </div>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={() => setIsModalOpen(false)}>Close</Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default Orders;