import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Table, Button } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import Barcode from 'react-barcode';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { packingSlipApis } from '../../config/apiRoutes/PackingslipRoutes'; // Adjust the import path as needed
import { PackingSlipItem } from '../../config/models/PackingSlip'; // Import the PackingSlip model

const ViewPackingSlip: React.FC = () => {
    const navigate = useNavigate();
    const { id } = useParams<{ id: string }>(); // Get the packing slip ID from the URL
    console.log(id);
    const packingSlipRef = useRef<HTMLDivElement>(null);

    const [packingSlipId, setPackingSlipId] = useState<string>('');
    const [date, setDate] = useState<string>('');
    const [items, setItems] = useState<PackingSlipItem[]>([]);
    const [notes, setNotes] = useState<string>('');

    // Fetch packing slip data when the component mounts
    useEffect(() => {
        const fetchPackingSlip = async () => {
            try {
                const response = await packingSlipApis.getPackingSlipById(id); // Fetch the packing slip by ID
                const { packingSlipId, date, items } = response.data; // Adjust according to your API response structure
                setPackingSlipId(packingSlipId);
                setDate(date);
                setItems(items);
                setNotes(notes);
            } catch (err) {
                console.error('Error fetching packing slip:', err);
                // Handle error (e.g., show a notification)
            }
        };

        if (id) fetchPackingSlip();
    }, [id]);

    // Function to save the packing slip as a PDF
    const saveAsPDF = () => {
        if (packingSlipRef.current) {
            html2canvas(packingSlipRef.current, { useCORS: true }).then((canvas) => {
                const pdf = new jsPDF('p', 'pt', 'a4'); // A4 size
                const imgData = canvas.toDataURL('image/png');
                const imgWidth = pdf.internal.pageSize.getWidth();
                const imgHeight = (canvas.height * imgWidth) / canvas.width;
                pdf.addImage(imgData, 'PNG', 0, 0, imgWidth, imgHeight);
                pdf.save('packing-slip.pdf'); // Save the PDF
            });
        }
    };

    return (
        <div className="mx-auto p-4 lg:px-8" ref={packingSlipRef}>
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold flex-grow text-center">View Packing Slip</h2>
                <Button color='green' onClick={saveAsPDF}>Download PDF</Button>
            </div>
            <div className="flex flex-col md:flex-row justify-between p-4">
                <div className="mb-4 md:mb-0 w-full md:w-1/5">
                    <h1 className="text-lg font-bold">LITTLESPILLS INC</h1>
                    <p>324 TRADERS BLVD</p>
                    <p>EAST MISSISSAUGA ON</p>
                    <p>L4Z 1W7</p>
                    <p>647-227-2525</p>
                    <p>littlespills.001@gmail.com</p>
                    <p>www.littlespills.com</p>
                    <p className="font-bold text-[18px] text-gray-600">Packing Slip ID: {packingSlipId}</p>
                    <h1 className="text-lg font-bold">BILL TO:</h1>
                    <p>Bill Address: 123 Example St, City, State, Zip</p>
                </div>
                <div className="flex flex-col justify-center items-center mb-4 md:mb-0">
                    <img src= "/logo.png" alt="Logo" className="h-[120px]" />
                </div>
                <div className="text-right">
                    <p className="font-bold">DATE: {date}</p>
                    <Barcode value={packingSlipId} />
                    <p className="font-bold mt-2">Purchase Order No: PO123456</p>
                    <p>Ship To: 456 Another St, City, State, Zip</p>
                </div>
            </div>
            <nav className="bg-gray-300 p-2 mb-14">
                <ul className="flex justify-around">
                    <li>Terms of Sale</li>
                    <li className="mr-[70%]">Ship Via</li>
                </ul>
            </nav>
            <section className="mb-4">
                <h2 className="text-lg font-semibold mb-2">Items List</h2>
                <Table>
                    <Table.Head>
                        <Table.HeadCell>ITEM No.</Table.HeadCell>
                        <Table.HeadCell>ITEM</Table.HeadCell>
                        <Table.HeadCell>DESCRIPTION</Table.HeadCell>
                        <Table.HeadCell>QTY</Table.HeadCell>
                    </Table.Head>
                    <Table.Body className="text-gray-600 text-sm font-light">
                        {items.map((item) => (
                            <Table.Row key={item.id} className="border-b border-gray-200 hover:bg-gray-100 transition-colors duration-300">
                                <Table.Cell>{item.itemNo}</Table.Cell>
                                <Table.Cell>{item.name}</Table.Cell>
                                <Table.Cell>{item.description}</Table.Cell>
                                <Table.Cell>{item.quantity}</Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </section>
            <footer className="text-center mt-4">
                <p>Thank you for your business...</p>
            </footer>
        </div>
    );
};

export default ViewPackingSlip;