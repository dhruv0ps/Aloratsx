import React, { useEffect, useState } from "react";
import { Button, TextInput } from "flowbite-react";
import { useNavigate } from "react-router-dom";
import Loading from "../../util/Loading";
import { FaChevronLeft } from "react-icons/fa6";
import { packingSlipApis } from "../../config/apiRoutes/PackingslipRoutes"; // Adjust the import path as needed
import { PackingSlip } from "../../config/models/PackingSlip"; // Import the updated PackingSlip model

const PackingSlipList: React.FC = () => {
  const [filteredPackingSlips, setFilteredPackingSlips] = useState<
    PackingSlip[]
  >([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [limit, setLimit] = useState<number>(10);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPackingSlips();
  }, [searchTerm, limit]);

  const fetchPackingSlips = async () => {
    setLoading(true);
    try {
      const response = await packingSlipApis.getAllPackingSlips();
      if (response.status) {
        setFilteredPackingSlips(response.data || []);
      }
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleLimitChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setLimit(Number(e.target.value));
  };

  const handleView = (packingSlipID: string) => {
    navigate(`/yellowadmin/PackingSlip/ViewPackingSlip/`, {
        state: { packingSlipID }
    });
};

  if (loading) return <Loading />;

  return (
    <div className="mx-auto p-4 lg:px-8">
      <div className="mb-12 flex items-center justify-between">
        <Button color="gray" onClick={() => navigate(-1)}>
          <span className="flex gap-2 items-center">
            <FaChevronLeft />
            Back
          </span>
        </Button>
        <h2 className="text-2xl font-semibold">Packing Slips Listing</h2>
        <Button
          color="green"
          onClick={() => navigate("/yellowadmin/PackingSlip/AddPackingSlip")}
        >
          <span className="flex gap-2 items-center">Add Packing Slip</span>
        </Button>
      </div>
      <div className="flex gap-6 justify-between items-end mb-6">
        <TextInput
          type="text"
          placeholder="Search by Packing Slip ID"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="flex-1"
        />
        <label className="flex flex-col text-gray-500">
          <span className="text-sm">Items per page</span>
          <select
            value={limit}
            onChange={handleLimitChange}
            className="rounded-md border-gray-300 py-2 px-4 focus:ring focus:ring-purple-200 transition"
          >
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </label>
      </div>
      <div className="overflow-x-auto">
        {filteredPackingSlips.length > 0 ? (
          <table className="min-w-full bg-white">
            <thead>
              <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                <th className="py-3 px-6 text-left">Packing Slip ID</th>
                <th className="py-3 px-6 text-left">Item No.</th>
                <th className="py-3 px-6 text-left">Item</th>
                <th className="py-3 px-6 text-left">Description</th>
                <th className="py-3 px-6 text-left">Quantity</th>
                <th className="py-3 px-6 text-left">Date</th>
                <th className="py-3 px-6 text-left">Action</th>
              </tr>
            </thead>
            <tbody className="text-gray-600 text-sm font-light">
              {filteredPackingSlips.map((packingSlip) => (
                <tr
                  key={packingSlip.packingSlipID}
                  className="border-b border-gray-200 hover:bg-gray-100"
                >
                  <td className="py-3 px-6 text-left">
                    {packingSlip.packingSlipID}
                  </td>
                  <td className="py-3 px-6 text-left">{packingSlip.itemNo}</td>
                  <td className="py-3 px-6 text-left">
                    {packingSlip.itemName}
                  </td>
                  <td className="py-3 px-6 text-left">
                    {packingSlip.description}
                  </td>
                  <td className="py-3 px-6 text-left">{packingSlip.qty}</td>
                  <td className="py-3 px-6 text-left">{packingSlip.date}</td>
                  <td className="py-3 px-6 text-left">
                    <Button
                      onClick={() => handleView(packingSlip.packingSlipID)}
                      className="bg-indigo-500 text-white hover:bg-indigo-600"
                    >
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <p>No Packing Slips Found</p>
        )}
      </div>
    </div>
  );
};

export default PackingSlipList;
