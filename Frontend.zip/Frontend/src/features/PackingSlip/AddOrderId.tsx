import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Label, TextInput } from 'flowbite-react';
import { packingSlipApis } from '../../config/apiRoutes/PackingslipRoutes';

const AddOrderId: React.FC = () => {
    const navigate = useNavigate();
    const [OrderNumber, setOrderNumber] = useState<string>(); // Set default OrderNumber
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');

    const handleFetchPackingSlip = async () => {
        setLoading(true);
        setError('');
        try {
            const response = await packingSlipApis.getPackingSlipByOrderId({ OrderNumber });
            if (response.status) {
                navigate('/yellowadmin/PackingSlip/AddPackingSlip', { state: response.data });
            } else {
                setError('Packing slip not found.');
            }
        } catch (err) {
            console.error(err);
            setError('An error occurred while generating the packing slip.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="mx-auto p-4 lg:px-8">
            <h2 className="text-2xl font-semibold text-center mb-4">Enter Order Number</h2>
            <div className="flex justify-center mb-4">
                {/* Label for the input */}
                <div className="w-full md:w-1/3">
                    <Label htmlFor="orderNumber" value="Order Number" />
                    <TextInput
                        id="orderNumber" // ID for the input field
                        type="text"
                        value={OrderNumber} // State value
                        onChange={(e) => setOrderNumber(e.target.value)} // Update state on change
                        placeholder="Enter Order Number"
                        className="mt-1"
                    />
                </div>
            </div>
            {error && <p className="text-red-500 text-center">{error}</p>}
            <div className="flex justify-center">
                <Button color="green" onClick={handleFetchPackingSlip} disabled={loading}>
                    {loading ? 'Loading...' : 'Generate Packing Slip'}
                </Button>
            </div>
        </div>
    );
};

export default AddOrderId;
