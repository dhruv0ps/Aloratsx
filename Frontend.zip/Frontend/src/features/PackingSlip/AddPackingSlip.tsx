import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Table, Button, TextInput } from "flowbite-react";
import { FaChevronLeft } from "react-icons/fa6";
import Barcode from "react-barcode";
import { packingSlipApis } from "../../config/apiRoutes/PackingslipRoutes";
import { PackingSlipItem } from "../../config/models/PackingSlip";
import { productApis } from "../../config/apiRoutes/productRoutes";
import SignatureCanvas from "react-signature-canvas";

const AddPackingSlip: React.FC = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const packingSlipData = location.state as any;
    const packingSlipRef = useRef<HTMLDivElement>(null);
    const signatureRef = useRef<SignatureCanvas>(null);
    const products = Array.isArray(packingSlipData?.products) ? packingSlipData.products : [];

    const [packingSlipId] = useState<string>(packingSlipData?.purchaseOrderNumber) ;
    const [date] = useState<string>(new Date(packingSlipData?.date).toLocaleDateString("en-GB") || "03/08/2024");
    const [items, setItems] = useState<PackingSlipItem[]>([]);
    const [termsOfSale, setTermsOfSale] = useState<string>(packingSlipData?.termsOfSale || "COD");
    const [shipVia, setShipVia] = useState<string>(packingSlipData?.transportation || "");
    const [customerPO, setCustomerPO] = useState<string>(packingSlipData?.purchaseOrderNumber || "");
    const [confirmationItemNos, setConfirmationItemNos] = useState<{ [key: string]: string; }>({});
    const [signature, setSignature] = useState<string | null>(null);

    useEffect(() => {
        const fetchProductDetails = async () => {
            try {
                const fetchedItems = await Promise.all(
                    products.map(async (product: any) => {
                        const response = await productApis.getProductById(product.product);
                        const productData = response.data;
                        return {
                            id: product._id,
                            itemNo: product.childSKU,
                            name: productData.name,
                            description: productData.description,
                            quantity: product.quantity,
                        };
                    })
                );
                setItems(fetchedItems);
            } catch (error) {
                console.error("Error fetching product details:", error);
            }
        };

        if (products.length > 0) {
            fetchProductDetails();
        }
    }, [products]);

    const handleSubmit = async () => {
        const allMatch = items.every((item) => item.itemNo === confirmationItemNos[item.id]);
        if (!allMatch) {
            alert("Item numbers do not match. Please confirm all items.");
            return;
        }

        try {
            const signatureData = signatureRef.current?.toDataURL("image/png");
            if (signatureData) {
                setSignature(signatureData);
            }
            await packingSlipApis.createPackingSlip({
                receivedSign: signatureData,
                orderDetails: packingSlipData._id,
            });
            navigate("/yellowadmin/PackingSlip/PackingSlipList");
        } catch (err) {
            console.error(err);
        }
    };

    const handleSaveSignature = () => {
        if (signatureRef.current) {
            setSignature(signatureRef.current.toDataURL("image/png"));
        }
    };

    return (
        <div className="mx-auto p-4 lg:px-8">
            <div className="mb-12 flex items-center justify-between flex-wrap">
                <Button color="gray" onClick={() => navigate(-1)}>
                    <span className="flex gap-2 items-center">
                        <FaChevronLeft /> Back
                    </span>
                </Button>
                <h2 className="text-2xl font-semibold flex-grow text-center"> Add Packing Slip </h2>
                <Button color="green" onClick={handleSubmit}> Mark as Completed </Button>
            </div>

            <div className="flex flex-col md:flex-row justify-between p-4" ref={packingSlipRef}>
                <div className="mb-4 md:mb-0 w-full md:w-1/3 lg:w-1/4">
                    <h1 className="text-lg font-bold">LITTLESPILLS INC</h1>
                    <h1 className="text-lg font-bold">BILL TO:</h1>
                    <p>Company: {packingSlipData?.companyName}</p>
                    <p>Address: {packingSlipData?.billTo?.address?.address}</p>
                </div>
                <div className="flex flex-col items-center mb-4 md:mb-0 w-full md:w-1/3 lg:w-1/4">
                    <img src="/logo.png" alt="Logo" className="h-[120px] mx-auto" />
                </div>
                <div>
                    <p className="font-bold">DATE: {date}</p>
                    <Barcode value={packingSlipId} />
                    <p className="font-bold mt-2">Purchase Order No: {customerPO}</p>
                    <p>Ship To: {packingSlipData?.shipTo?.address?.address}</p>
                </div>
            </div>

            <nav className="bg-gray-300 p-2 mb-14">
                <ul className="flex justify-around flex-wrap">
                    <li className="flex-1 text-center">
                        <label className="block text-sm font-medium text-gray-700 cursor-pointer">
                            Terms of Sale: {termsOfSale}
                        </label>
                        {/* Dropdown for Terms of Sale */}
                        {/* Add your dropdown logic here */}
                    </li>
                    <li className="flex-1 text-center">
                        <label className="block text-sm font-medium text-gray-700 cursor-pointer">
                            Ship Via: {shipVia}
                        </label>
                        {/* Input for Ship Via */}
                        {/* Add your input logic here */}
                    </li>
                    <li className="flex-1 text-center">
                        <label className="block text-sm font-medium text-gray-700 cursor-pointer">
                            Customer PO: {customerPO}
                        </label>
                        {/* Input for Customer PO */}
                        {/* Add your input logic here */}
                    </li>
                </ul>
            </nav>

            <form>
                <Table>
                    <Table.Head>
                        <Table.HeadCell>Confirm Item No.</Table.HeadCell>
                        <Table.HeadCell>ITEM No.</Table.HeadCell>
                        <Table.HeadCell>Name</Table.HeadCell>
                        <Table.HeadCell>Description</Table.HeadCell>
                        <Table.HeadCell>Quantity</Table.HeadCell>
                    </Table.Head>
                    <Table.Body>
                        {items.map((item) => (
                            <Table.Row key={item.id}>
                                <Table.Cell>
                                    <TextInput
                                        type="text"
                                        value={confirmationItemNos[item.id] || ""}
                                        onChange={(e) => setConfirmationItemNos({ ...confirmationItemNos, [item.id]: e.target.value })}
                                        placeholder="Enter item number"
                                        style={{
                                            backgroundColor:
                                                confirmationItemNos[item.id] === ""
                                                    ? "transparent"
                                                    : confirmationItemNos[item.id] === item.itemNo
                                                    ? "lightgreen"
                                                    : "lightcoral",
                                        }}
                                    />
                                </Table.Cell>
                                <Table.Cell>{item.itemNo}</Table.Cell>
                                <Table.Cell>{item.name}</Table.Cell>
                                <Table.Cell>{item.description}</Table.Cell>
                                <Table.Cell>{item.quantity}</Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </form>

            <div className="mt-4 float-right bg-gray-200 p-4 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold">Signature</h3>
                <SignatureCanvas
                    ref={signatureRef}
                    penColor="black"
                    canvasProps={{ width: 150, height: 75, className: "signature-pad" }} // Adjusted size
                />
                <Button onClick={handleSaveSignature} color="blue" className="mt-5"> Save Signature </Button>
            </div>

        </div>
    );
};

export default AddPackingSlip;
