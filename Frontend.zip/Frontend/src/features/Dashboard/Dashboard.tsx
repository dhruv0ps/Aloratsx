
const Dashboard = () => {
  return (
    <div className="text-center pt-64 text-gray-500 text-2xl">Dashboard</div>
  )
}

export default Dashboard