import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button, TextInput, Select, Table } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { transactionApis } from '../../config/apiRoutes/TransactionRoutes'; // Adjust the import path as needed
import { Transaction } from '../../config/models/Transaction'; // Import the Transaction model

const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
};

const TransactionList: React.FC = () => {
    const [transactions, setTransactions] = useState<Transaction[]>([]);
    const [dateFilter, setDateFilter] = useState<string>(''); 
    const [dealerFilter, setDealerFilter] = useState<string>(''); 
    const [searchDealer, setSearchDealer] = useState<string>(''); 
    const [searchInvoiceNo, setSearchInvoiceNo] = useState<string>(''); 
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchTransactions = async () => {
            try {
                const response = await transactionApis.getAllTransactions();
                if (response.status === 200) {
                    setTransactions(response.data.transaction.transactions);
                } else {
                    throw new Error('Failed to fetch transactions');
                }
            } catch (error) {
                console.error('Error fetching transactions:', error);
                setError('Failed to fetch transactions.');
            }
        };

        fetchTransactions();
    }, []);

    const filteredTransactions = transactions.filter(transaction => {
        const transactionDate = new Date(transaction.transactionDate);
        const filterDate = new Date(dateFilter);
    
        const matchesDate = dateFilter
            ? transactionDate.toDateString() === filterDate.toDateString()
            : true;
        const matchesDealer = dealerFilter ? transaction.dealer === dealerFilter : true;
        const matchesSearchDealer = searchDealer ? transaction.dealer.toLowerCase().includes(searchDealer.toLowerCase()) : true;
        const matchesSearchInvoiceNo = searchInvoiceNo ? transaction.invoiceId.toLowerCase().includes(searchInvoiceNo.toLowerCase()) : true;
    
        return matchesDate && matchesDealer && matchesSearchDealer && matchesSearchInvoiceNo;
    });    

    const navigate = useNavigate();

    // Handle delete transaction
    const handleDelete = async (transactionId: string) => {
        try {
            await transactionApis.deleteTransaction(transactionId);
            setTransactions(transactions.filter(transaction => transaction.transactionId !== transactionId));
        } catch (error) {
            console.error('Error deleting transaction:', error);
            setError('Failed to delete transaction.');
        }
    };

    return (
        <div className="p-4 max-w-6xl mx-auto mt-12">
            {error && <div className="text-red-500 mb-4">{error}</div>}
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h1 className="text-2xl font-bold text-center flex-grow">Transaction List</h1>
            </div>
            <Link to="/yellowadmin/Transaction/AddTransaction" className="mb-4 inline-block bg-purple-600 text-white hover:bg-purple-700 px-4 py-2 rounded">
                Add Transaction
            </Link>
            <div className="mb-4 flex justify-between">
                <div className="flex space-x-4">
                    <div>
                        <label htmlFor="date" className="block text-sm font-medium text-gray-700">Filter by Date</label>
                        <input type="date" id="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" />
                    </div>
                    <div>
                        <label htmlFor="dealer" className="block text-sm font-medium text-gray-700">Filter by Dealer</label>
                        <Select
                            id="dealer"
                            value={dealerFilter}
                            onChange={(e) => setDealerFilter(e.target.value)}
                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        >
                            <option value="">Select Dealer</option>
                            <option value="Dealer Dummy">Dealer Dummy</option>
                            {/* Add more options dynamically if needed */}
                        </Select>
                    </div>
                </div>
                <div className="flex space-x-4">
                    <div>
                        <label htmlFor="searchDealer" className="block text-sm font-medium text-gray-700">Search Dealer</label>
                        <TextInput
                            type="text"
                            id="searchDealer"
                            value={searchDealer}
                            onChange={(e) => setSearchDealer(e.target.value)}
                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        />
                    </div>
                    <div>
                        <label htmlFor="searchInvoiceNo" className="block text-sm font-medium text-gray-700">Search Invoice No</label>
                        <TextInput
                            type="text"
                            id="searchInvoiceNo"
                            value={searchInvoiceNo}
                            onChange={(e) => setSearchInvoiceNo(e.target.value)}
                            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                        />
                    </div>
                </div>
            </div>
            <Table>
                <Table.Head>
                    <Table.HeadCell>Transaction ID</Table.HeadCell>
                    <Table.HeadCell>Date</Table.HeadCell>
                    <Table.HeadCell>Dealer</Table.HeadCell>
                    <Table.HeadCell>Invoice No</Table.HeadCell>
                    <Table.HeadCell className="text-center">Action</Table.HeadCell>
                </Table.Head>
                <Table.Body>
                    {filteredTransactions.map((transaction) => (
                        <Table.Row key={transaction.transactionId} className="hover:bg-gray-100">
                            <Table.Cell>{transaction.transactionId}</Table.Cell>
                            <Table.Cell>{formatDate(transaction.transactionDate)}</Table.Cell>
                            <Table.Cell>{transaction.dealer}</Table.Cell>
                            <Table.Cell>{transaction.invoiceId}</Table.Cell>
                            <Table.Cell className="flex justify-center space-x-2">
                                <Button color="warning" className="bg-yellow-400 hover:bg-yellow-500">
                                    Edit
                                </Button>
                                <Button color="failure" onClick={() => handleDelete(transaction.transactionId)}>
                                    Delete
                                </Button>
                            </Table.Cell>
                        </Table.Row>
                    ))}
                </Table.Body>
            </Table>
        </div>
    );
};

export default TransactionList;
