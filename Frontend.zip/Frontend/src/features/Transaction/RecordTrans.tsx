import React, { useState, useEffect, ChangeEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, TextInput, Select, Table } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { transactionApis } from '../../config/apiRoutes/TransactionRoutes'; // Import your API routes

interface Item {
  item: string;
  invoiceNumber: string;
  totalAmount: number;
  dueAmount: number;
  capturedAmount?: number; // Optional field to hold captured amount
}

interface Dealer {
  _id: string; // Dealer ID
  contactPersonName: string;
}

const RecordTrans: React.FC = () => {
  const [dealer, setDealer] = useState<string>(''); // Selected dealer ID
  const [dealers, setDealers] = useState<Dealer[]>([]); // List of dealers with ID and name
  const [items, setItems] = useState<Item[]>([]); // List of invoices
  const [showSaveButton, setShowSaveButton] = useState<boolean>(false); // For showing the Save Record button

  const navigate = useNavigate();

  useEffect(() => {
    const fetchDealers = async () => {
      try {
        const response = await transactionApis.getAllDealers();
        const responseData: Dealer[] = response.data.data; // Assuming response.data.data holds dealer list
        setDealers(responseData);
      } catch (error) {
        console.error("Error fetching dealers:", error);
      }
    };

    fetchDealers();
  }, []);

  useEffect(() => {
    if (dealer) {
      const fetchInvoices = async () => {
        try {
          const response = await transactionApis.getInvoiceList({ id: dealer });
          console.log(response.data);
          const responseData: Item[] = response.data.invoice.invoices || []; // Ensure it's an array
          setItems(responseData);
        } catch (error) {
          console.error("Error fetching invoices:", error);
        }
      };

      fetchInvoices();
    } else {
      setItems([]); // Clear items when no dealer is selected
    }
  }, [dealer]);

  const handleStartRecording = () => {
    console.log('Start recording clicked');
  };

  const handleSaveRecord = async () => {
    try {
      // Prepare the transaction data
      const transactionPromises = items
        .filter(item => item.capturedAmount && item.capturedAmount > 0)
        .map(async item => {
          // Create transaction data for each item
          const transactionData = {
            invoiceNumber: item.invoiceNumber, 
            capturedAmount: item.capturedAmount,
          };

          // Call the API to add the transaction
          const response = await transactionApis.addTransaction(transactionData);
          console.log('Transaction response:', response.data);
        });

      await Promise.all(transactionPromises);
      // Redirect to the transaction list page
      navigate('/yellowadmin/Transaction/TransactionList');
    } catch (error) {
      console.error("Error saving record:", error);
    }
  };

  const handleDealerChange = (e: ChangeEvent<HTMLSelectElement>) => {
    setDealer(e.target.value);
  };

  const handleCaptureAmountChange = (e: ChangeEvent<HTMLInputElement>, index: number) => {
    const newItems = [...items];
    const capturedAmount = parseFloat(e.target.value) || 0;
    newItems[index].capturedAmount = capturedAmount;
    setItems(newItems);

    // Show the Save button if at least one item has a captured amount greater than 0
    const hasCapturedAmount = newItems.some(item => item.capturedAmount && item.capturedAmount > 0);
    setShowSaveButton(hasCapturedAmount);
  };

  return (
    <div className="p-4 max-w-4xl mx-auto mt-12">
      <div className="mb-12 flex items-center justify-between">
        <Button color="gray" onClick={() => navigate(-1)}>
          <span className="flex gap-2 items-center">
            <FaChevronLeft />
            Back
          </span>
        </Button>
        <h1 className="text-2xl font-bold text-center">RECORD A TRANSACTION</h1>
      </div>

      {/* Dealer selection */}
      <div className="mb-4">
        <label htmlFor="dealer" className="block text-sm font-medium text-gray-700">
          Select Dealer
        </label>
        <Select
          id="dealer"
          value={dealer}
          onChange={handleDealerChange}
          className="mt-1 block border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
        >
          <option value="">Select Dealer</option>
          {dealers.map((dealer) => (
            <option key={dealer._id} value={dealer._id}>
              {dealer.contactPersonName}
            </option>
          ))}
        </Select>
      </div>

      {/* Conditionally show this section only if a dealer is selected */}
      {dealer && (
        <>
          <Button onClick={handleStartRecording} color="primary" className="mb-4">
            Start Recording
          </Button>

          {/* Items table */}
          {items.length > 0 ? (
            <Table>
              <Table.Head>
                <Table.HeadCell>Item List</Table.HeadCell>
                <Table.HeadCell>Invoice No</Table.HeadCell>
                <Table.HeadCell>Total Amount</Table.HeadCell>
                <Table.HeadCell>Due Amount</Table.HeadCell>
                <Table.HeadCell>Capture Amount</Table.HeadCell>
              </Table.Head>
              <Table.Body>
                {items.map((item, index) => (
                  <Table.Row key={index}>
                    <Table.Cell>Item {index + 1}</Table.Cell>
                    <Table.Cell>{item.invoiceNumber}</Table.Cell>
                    <Table.Cell>${item.totalAmount}</Table.Cell>
                    <Table.Cell>${item.dueAmount}</Table.Cell>
                    <Table.Cell>
                      <TextInput
                        type="number"
                        placeholder="Enter Amount"
                        min="0" // Prevent negative values
                        className="w-full"
                        onChange={(e) => handleCaptureAmountChange(e, index)}
                      />
                    </Table.Cell>
                  </Table.Row>
                ))}
              </Table.Body>
            </Table>
          ) : (
            <p>No invoices for this dealer</p> // Message when no invoices are found
          )}
        </>
      )}

      {/* Conditionally show the Save Record button only if a captured amount is entered */}
      {showSaveButton && (
        <Button onClick={handleSaveRecord} color="success" className="mt-4">
          Save Record
        </Button>
      )}
    </div>
  );
};

export default RecordTrans;
