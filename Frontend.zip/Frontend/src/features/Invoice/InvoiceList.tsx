import React, { useState, useEffect } from 'react';
import { Button, TextInput, Select, Table } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { useNavigate } from 'react-router-dom';
import { invoiceApis } from '../../config/apiRoutes/InvoiceRoutes'; // Adjust the import path as needed
import { InvoiceData } from '../../config/models/Invoice'; // Import the Invoice model

const InvoiceList: React.FC = () => {
    const navigate = useNavigate();
    const [invoices, setInvoices] = useState<InvoiceData[]>([]);
    const [searchTerm, setSearchTerm] = useState<string>('');
    const [sortOption, setSortOption] = useState<string>('newest');
    const [filterStatus, setFilterStatus] = useState<string>('all');
    const [filterTaxSlab, setFilterTaxSlab] = useState<string>('all');
    const [filterCustomer, setFilterCustomer] = useState<string>('');
    const [dateRange, setDateRange] = useState<{ start: string; end: string }>({ start: '', end: '' });
    const [loading, setLoading] = useState<boolean>(true); // Loading state
    const [error, setError] = useState<string | null>(null); // Error state

    useEffect(() => {
        const fetchInvoices = async () => {
            setLoading(true);
            try {
                const response = await invoiceApis.getAllInvoices();
                console.log('API response:', response); // Debugging response
                if (response.status && response.data && response.data.invoices && response.data.invoices.invoices) {
                    console.log('Fetched invoices:', response.data.invoices.invoices); // Debugging invoices
                    setInvoices(response.data.invoices.invoices); // Correctly access invoices field
                } else {
                    throw new Error('Invalid response structure');
                }
            } catch (error) {
                console.error('Error fetching invoices:', error);
                setError('Failed to fetch invoices.');
            } finally {
                setLoading(false);
            }
        };
    
        fetchInvoices();
    }, []);
    

    // Ensure invoices is always an array
    const filteredAndSortedInvoices = (Array.isArray(invoices) ? invoices : [])
    .filter((invoice) =>
        invoice.invoiceID?.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter((invoice) =>
        filterStatus === 'all' || invoice.status?.toLowerCase() === filterStatus.toLowerCase()
    )
    .filter((invoice) =>
        filterTaxSlab === 'all' || invoice.taxSlab?.toLowerCase() === filterTaxSlab.toLowerCase()
    )
    .filter((invoice) =>
        filterCustomer === '' || invoice.builtTo?.toLowerCase().includes(filterCustomer.toLowerCase())
    )
    .filter((invoice) => {
        const invoiceDate = new Date(invoice.dueDate);
        const startDate = new Date(dateRange.start);
        const endDate = new Date(dateRange.end);
        return (!dateRange.start || invoiceDate >= startDate) && (!dateRange.end || invoiceDate <= endDate);
    })
    .sort((a, b) => {
        if (sortOption === 'newest') {
            return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
        } else if (sortOption === 'oldest') {
            return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        } else {
            return a.status?.localeCompare(b.status || '') || 0;
        }
    });


    const handleViewInvoice = (invoiceId: string) => {
        navigate(`/InvoiceSummary?id=${invoiceId}`);
    };

    return (
        <div className="mx-auto p-4 lg:px-8">
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold flex-grow text-center">Invoice List</h2>
            </div>
            {loading && <p>Loading...</p>}
            {error && <p className="text-red-500">{error}</p>}
            {!loading && !error && (
                <>
                    <div className='flex gap-6 justify-between items-center mb-6'>
                        <TextInput
                            type="text"
                            placeholder="Search by Invoice ID"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="flex-1"
                        />
                        <Select
                            value={sortOption}
                            onChange={(e) => setSortOption(e.target.value)}
                            className="ml-2"
                        >
                            <option value="newest">Sort by Newest Due Date</option>
                            <option value="oldest">Sort by Oldest Due Date</option>
                            <option value="status">Sort by Status</option>
                        </Select>
                        <Select
                            value={filterStatus}
                            onChange={(e) => setFilterStatus(e.target.value)}
                            className="ml-2"
                        >
                            <option value="all">All Statuses</option>
                            <option value="paid">Paid</option>
                            <option value="unpaid">Unpaid</option>
                            <option value="partially_paid">Partially Paid</option>
                        </Select>
                        <Select
                            value={filterTaxSlab}
                            onChange={(e) => setFilterTaxSlab(e.target.value)}
                            className="ml-2"
                        >
                            <option value="all">All Tax Slabs</option>
                            <option value="standard">Standard</option>
                            <option value="reduced">Reduced</option>
                            <option value="zero">Zero</option>
                        </Select>
                        <TextInput
                            type="text"
                            placeholder="Filter by Customer"
                            value={filterCustomer}
                            onChange={(e) => setFilterCustomer(e.target.value)}
                            className="flex-1"
                        />
                        <div className="flex gap-2">
                            <TextInput
                                type="date"
                                placeholder="Start Date"
                                value={dateRange.start}
                                onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
                            />
                            <TextInput
                                type="date"
                                placeholder="End Date"
                                value={dateRange.end}
                                onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
                            />
                        </div>
                    </div>
                    <div className="overflow-x-auto">
                    <Table>
    <Table.Head>
        <Table.HeadCell>Invoice ID</Table.HeadCell>
        <Table.HeadCell>Built To</Table.HeadCell>
        <Table.HeadCell>Total Amount</Table.HeadCell>
        <Table.HeadCell>Due Amount</Table.HeadCell>
        <Table.HeadCell>Due Date</Table.HeadCell>
        <Table.HeadCell>Status</Table.HeadCell>
        <Table.HeadCell>Tax Slab</Table.HeadCell>
        <Table.HeadCell>Action</Table.HeadCell>
    </Table.Head>
    <Table.Body className="divide-y">
        {filteredAndSortedInvoices.length > 0 ? (
            filteredAndSortedInvoices.map((invoice) => (
                <Table.Row key={invoice.invoiceID} className="bg-white hover:bg-gray-100">
                    <Table.Cell className="whitespace-nowrap font-medium text-gray-900">{invoice.invoiceID}</Table.Cell>
                    <Table.Cell>{invoice.builtTo}</Table.Cell>
                    <Table.Cell>${invoice.totalAmount.toFixed(2)}</Table.Cell>
                    <Table.Cell>${invoice.dueAmount.toFixed(2)}</Table.Cell>
                    <Table.Cell>{invoice.dueDate}</Table.Cell>
                    <Table.Cell>
                        <span
                            className={`px-2 py-1 rounded-full text-xs font-medium ${
                                invoice.status === 'Unpaid'
                                    ? 'bg-red-100 text-red-600'
                                    : invoice.status === 'Paid'
                                        ? 'bg-green-100 text-green-600'
                                        : 'bg-yellow-100 text-yellow-600'
                            }`}
                        >
                            {invoice.status}
                        </span>
                    </Table.Cell>
                    <Table.Cell>{invoice.taxSlab}</Table.Cell>
                    <Table.Cell>
                        <Button
                            onClick={() => handleViewInvoice(invoice.invoiceID)}
                            className="bg-purple-600 text-white hover:bg-purple-700"
                        >
                            View
                        </Button>
                    </Table.Cell>
                </Table.Row>
            ))
        ) : (
            <Table.Row>
                <Table.Cell colSpan={8} className="text-center py-4">No invoices found</Table.Cell>
            </Table.Row>
        )}
    </Table.Body>
</Table>

                    </div>
                </>
            )}
        </div>
    );
};

export default InvoiceList;
