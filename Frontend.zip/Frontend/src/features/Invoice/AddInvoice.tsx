import React, { useState, useEffect } from 'react';
import { Button, TextInput, Table } from 'flowbite-react';
import { FaChevronLeft } from 'react-icons/fa6';
import { useNavigate } from 'react-router-dom';
import { invoiceApis } from '../../config/apiRoutes/InvoiceRoutes';
import { transactionApis } from "../../config/apiRoutes/TransactionRoutes";
import { Order, InvoiceItem } from '../../config/models/Invoice';

const AddInvoice: React.FC = () => {
    const navigate = useNavigate();
    const [selectedDealer, setSelectedDealer] = useState<string>('');
    const [orders, setOrders] = useState<Order[]>([]);
    const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
    const [invoiceStatus, setInvoiceStatus] = useState<string>('Unpaid');
    const [taxSlab, setTaxSlab] = useState<string>('Standard');
    const [invoiceId, setInvoiceId] = useState<string | null>(null);
    const [total, setTotal] = useState<number>(0);
    const [isFinalized, setIsFinalized] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const [dealers, setDealers] = useState<{ [key: string]: string }>({});
    const [taxSlabs, setTaxSlabs] = useState<{ [key: string]: string }>({});

    useEffect(() => {
        const fetchDealersAndTaxSlabs = async () => {
            setLoading(true);
            try {
                const dealerResponse = await transactionApis.getAllDealers();
                const taxSlabResponse = await invoiceApis.getAllTaxSlabs();

                if (dealerResponse.status) {
                    const dealerOptions = dealerResponse.data.data.reduce((acc: { [key: string]: string }, dealer: any) => {
                        acc[dealer.contactPersonName] = dealer._id;
                        return acc;
                    }, {});
                    setDealers(dealerOptions);

                    const taxSlabOptions = taxSlabResponse.data.data.reduce((acc: { [key: string]: string }, slab: any) => {
                        acc[slab.name] = slab._id;
                        return acc;
                    }, {});
                    setTaxSlabs(taxSlabOptions);
                }
            } catch (error) {
                console.error('Error fetching dealers and tax slabs:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchDealersAndTaxSlabs();
    }, []);

    useEffect(() => {
        const fetchOrders = async () => {
            if (selectedDealer) {
                try {
                    const response = await invoiceApis.getAllOrders({ id: selectedDealer });
                    if (response.status) {
                        // Update orders based on API response structure
                        const fetchedOrders = response.data.data.map((order: any) => ({
                            id: order.id,
                            name: order.products[0]?.name || 'Unknown',
                            items: order.products.map((product: any) => ({
                                id: product._id, // Ensure item ID is correct
                                price: product.price,
                                quantity: product.quantity,
                            }))
                        }));
                        setOrders(fetchedOrders);
                    }
                } catch (error) {
                    console.error('Error fetching orders:', error);
                }
            }
        };

        fetchOrders();
    }, [selectedDealer]);

    const handleDealerChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setSelectedDealer(e.target.value);
    };

    const handleOrderSelection = (order: Order) => {
        const newItems = order.items.map(item => ({
            id: item.id,
            itemNo: order.name,
            price: item.price,
            quantity: item.quantity,
            orderId: order.id, // Add this line to include the order ID
        }));
    
        const uniqueItems = newItems.filter(newItem => !invoiceItems.some(existingItem => existingItem.id === newItem.id));
        setInvoiceItems(prevItems => [...prevItems, ...uniqueItems]);
        setTotal(prevTotal => prevTotal + uniqueItems.reduce((sum, item) => sum + item.price * item.quantity, 0));
    };    

    const handleQuantityChange = (index: number, value: string) => {
        const newQuantity = Math.max(0, parseInt(value) || 0);
        const updatedItems = [...invoiceItems];
        updatedItems[index].quantity = newQuantity;
        setInvoiceItems(updatedItems);
        setTotal(prevTotal => prevTotal - invoiceItems[index].price * invoiceItems[index].quantity + updatedItems[index].price * newQuantity);
    };

    const handlePriceChange = (index: number, value: string) => {
        const newPrice = Math.max(0, parseFloat(value) || 0);
        const updatedItems = [...invoiceItems];
        updatedItems[index].price = newPrice;
        setInvoiceItems(updatedItems);
        setTotal(prevTotal => prevTotal - invoiceItems[index].price * invoiceItems[index].quantity + newPrice * updatedItems[index].quantity);
    };

    const handleNext = () => {
        const newInvoiceId = 'INV' + Math.floor(Math.random() * 10000);
        setInvoiceId(newInvoiceId);
        setIsFinalized(true);
    };

    const gst = total * 0.05;
    const hst = total * 0.13;
    const transportation = 20;
    const grandTotal = total + gst + hst + transportation;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const orderId = invoiceItems.map(item => item.orderId).toString();
        console.log(orderId)
        try {
            await invoiceApis.addInvoice({
                dealer: selectedDealer,
                order: orderId, // Use item.orderId for order IDs
                taxSlab_id: taxSlab,
                invoiceId,
                total,
                gst,
                hst,
                transportation,
                grandTotal,
                invoiceItems,
                invoiceStatus,
            });
            navigate('/yellowadmin/Invoice/InvoiceSummary');
        } catch (error) {
            console.error('Error submitting invoice:', error);
        }
    };    

    return (
        <div className="p-4 max-w-4xl mx-auto mt-6">
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold flex-grow text-center">{isFinalized ? 'Invoice' : 'Create Invoice'}</h2>
            </div>
            {!isFinalized && (
                <>
                    <div className="mb-4">
                        <label htmlFor="dealer" className="block text-sm font-medium text-gray-700">Select Dealer</label>
                        <select id="dealer" value={selectedDealer} onChange={handleDealerChange} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="">Select Dealer</option>
                            {Object.keys(dealers).map(contactPersonName => (
                                <option key={dealers[contactPersonName]} value={dealers[contactPersonName]}>{contactPersonName}</option>
                            ))}
                        </select>
                    </div>
                    {orders.length > 0 && (
                        <div className="mb-4">
                            <h2 className="text-lg font-semibold">Available Orders</h2>
                            <table className="min-w-full border-collapse border border-gray-300 mt-2">
                                <thead>
                                    <tr className="bg-gray-200">
                                        <th className="border border-gray-300 px-4 py-2">ITEM No.</th>
                                        <th className="border border-gray-300 px-4 py-2">ITEM</th>
                                        <th className="border border-gray-300 px-4 py-2">PRICE</th>
                                        <th className="border border-gray-300 px-4 py-2">QTY</th>
                                        <th className="border border-gray-300 px-4 py-2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {orders.map((order, index) => (
                                        <tr key={order.id}>
                                            <td className="border border-gray-300 px-4 py-2">{index + 1}</td>
                                            <td className="border border-gray-300 px-4 py-2">{order.name}</td>
                                            <td className="border border-gray-300 px-4 py-2">${(order.items.reduce((sum, item) => sum + item.price, 0) || 0).toFixed(2)}</td>
                                            <td className="border border-gray-300 px-4 py-2">{(order.items.reduce((sum, item) => sum + item.quantity, 0) || 0)}</td>
                                            <td className="border border-gray-300 px-4 py-2">
                                                <button type="button" onClick={() => handleOrderSelection(order)} className="px-2 py-1 text-white bg-blue-500 rounded hover:bg-blue-600">Add</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}
                    <div className="mb-4">
                        <label htmlFor="tax-slab" className="block text-sm font-medium text-gray-700">Select Tax Slab</label>
                        <select id="tax-slab" value={taxSlab} onChange={(e) => setTaxSlab(e.target.value)} className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm">
                            <option value="">Select Tax Slab</option>
                            {Object.keys(taxSlabs).map(slabName => (
                                <option key={taxSlabs[slabName]} value={taxSlabs[slabName]}>{slabName}</option>
                            ))}
                        </select>
                    </div>
                    <Button onClick={handleNext} className="w-full bg-blue-500 text-white">Next</Button>
                </>
            )}
            {isFinalized && (
                <form onSubmit={handleSubmit}>
                    <h2 className="text-lg font-semibold mb-4">Finalize Invoice</h2>
                    <Table>
                        <Table.Head>
                            <Table.HeadCell>ITEM No.</Table.HeadCell>
                            <Table.HeadCell>ITEM</Table.HeadCell>
                            <Table.HeadCell>PRICE</Table.HeadCell>
                            <Table.HeadCell>QTY</Table.HeadCell>
                            <Table.HeadCell>AMOUNT</Table.HeadCell>
                        </Table.Head>
                        <Table.Body>
                            {invoiceItems.map((item, index) => (
                                <Table.Row key={item.id}>
                                    <Table.Cell>{index + 1}</Table.Cell>
                                    <Table.Cell>{item.itemNo}</Table.Cell>
                                    <Table.Cell>
                                        <TextInput
                                            type="number"
                                            value={item.price}
                                            onChange={(e) => handlePriceChange(index, e.target.value)}
                                            min="0"
                                            step="0.01"
                                        />
                                    </Table.Cell>
                                    <Table.Cell>
                                        <TextInput
                                            type="number"
                                            value={item.quantity}
                                            onChange={(e) => handleQuantityChange(index, e.target.value)}
                                            min="0"
                                        />
                                    </Table.Cell>
                                    <Table.Cell>${(item.price * item.quantity).toFixed(2)}</Table.Cell>
                                </Table.Row>
                            ))}
                        </Table.Body>
                    </Table>
                    <div className="mt-4">
                        <div className="flex justify-between mb-2">
                            <span>Total:</span>
                            <span>${total.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-2">
                            <span>GST (5%):</span>
                            <span>${gst.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-2">
                            <span>HST (13%):</span>
                            <span>${hst.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between mb-2">
                            <span>Transportation:</span>
                            <span>${transportation.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between font-bold">
                            <span>Grand Total:</span>
                            <span>${grandTotal.toFixed(2)}</span>
                        </div>
                    </div>
                    <Button type="submit" className="w-full bg-blue-500 text-white mt-4">Submit Invoice</Button>
                </form>
            )}
        </div>
    );
};

export default AddInvoice;
