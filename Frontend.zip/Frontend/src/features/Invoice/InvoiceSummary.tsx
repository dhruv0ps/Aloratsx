import React, { useState, useEffect } from 'react';

import { useNavigate } from 'react-router-dom';
import { invoiceApis } from '../../config/apiRoutes/InvoiceRoutes';
import { InvoiceData, InvoiceItem } from '../../config/models/Invoice'; 

const InvoiceSummary: React.FC = () => {
    const navigate = useNavigate();
    const [invoiceData, setInvoiceData] = useState<InvoiceData | null>(null);
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(() => {
        const fetchInvoiceData = async () => {
            setLoading(true);
            const urlParams = new URLSearchParams(window.location.search);
            const id = urlParams.get('id'); // Get the invoice ID from the URL

            if (id) {
                try {
                    const response = await invoiceApis.getAllInvoices();
                    // Ensure the response data has the correct type
                    const foundInvoice: InvoiceData | undefined = response.data.find((invoice: InvoiceData) => invoice.id === id); // Find the specific invoice
                    if (foundInvoice) {
                        setInvoiceData(foundInvoice);
                    }
                } catch (error) {
                    console.error("Error fetching invoice data:", error);
                }
            }
            setLoading(false);
        };

        fetchInvoiceData();
    }, []);

    const handleConfirm = () => {
        navigate('/invoicelist');
    };

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!invoiceData) {
        return <div>No invoice data found.</div>;
    }

    const total = invoiceData.grandTotal; // Assuming grandTotal is part of the invoiceData

    return (
        <>
            <div className="flex justify-end mt-4">
                <button
                    onClick={handleConfirm}
                    className="mr-4 px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                >
                    Confirm
                </button>
            </div>
            <div className="flex">
                {/* Main Content Area */}
                <div className="flex-1 p-4">
                    <div className="p-4 max-w-4xl mx-auto mt-6 relative" id="invoice">
                        <div className="absolute top-4 right-4 text-gray-600 text-right flex flex-col items-end mt-24 mr-8">
                            <div className="flex items-center mr-14">
                                <p className="font-bold mr-2">Date:</p>
                                <p>{new Date().toLocaleDateString()}</p>
                            </div>
                            <img src="logo1.png" alt="Logo" className="mt-8 w-[23%] h-auto" />
                            <div className="bg-gray-300 px-[20.5%] py-2 mt-4 pl-2">
                                <p className="font-bold">INVOICE {invoiceData.id}</p>
                            </div>
                            <div className="bg-gray-300 px-[14%] py-2 mt-2 ml-auto pl-2">
                                <p className="font-bold">DUE DATE {new Date(invoiceData.dueDate).toLocaleDateString()}</p>
                            </div>
                        </div>

                        <h1 className="text-xl font-bold mb-4 text-black-600">Invoice Summary</h1>
                        <div className="bg-gray-100 pl-8 rounded-md shadow-md">
                            <h2 className="text-lg font-semibold mb-2 mt-10 text-black-600">LITTLESPILLS INC</h2>
                            <p className="text-gray-600">324 TRADERS BLVD EAST</p>
                            <p className="text-gray-600">MISSISSAUGA ON L4Z 1W7</p>
                            <p className="text-gray-600">+16472272525</p>
                            <p className="text-gray-600">littlespills.001@gmail.com</p>
                            <p className="text-gray-600">www.littlespills.com</p>

                            <h2 className="text-lg font-semibold mb-2 mt-6 text-black-600">BILL TO</h2>
                            <p className="text-gray-600">Hilltop Dry Goods</p>
                            <p className="text-gray-600">123 Main Street</p>
                            <p className="text-gray-600">City, ON K1T 2T1</p>
                            <p className="text-gray-600">Business account number</p>
                            <p className="text-gray-600">987654321 RT 0001</p>

                            {/* Invoice Details Table */}
                            <table className="w-[96%] mt-4">
                                <thead>
                                    <tr className="bg-gray-200">
                                        <th className="px-4 py-2 text-left">ITEM No.</th>
                                        <th className="px-4 py-2 text-left">QTY</th>
                                        <th className="px-4 py-2 text-left">RATE</th>
                                        <th className="px-4 py-2 text-left">AMOUNT</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {invoiceData.items.map((item: InvoiceItem) => (
                                        <tr key={item.id}>
                                            <td className="px-4 py-2">{item.itemNo}</td>
                                            <td className="px-4 py-2">{item.quantity}</td>
                                            <td className="px-4 py-2">${item.price.toFixed(2)}</td>
                                            <td className="px-4 py-2">${(item.price * item.quantity).toFixed(2)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                            {/* Total Summary Section */}
                            <div className="bg-gray-300 px-[14%] py-2 mt-2 ml-auto pl-2">
                                <div className="flex ml-[64%]">
                                    <p className="font-bold ml-[-100px]">TOTAL:</p>
                                    <p className='text-right pl-[150%]'>${total.toFixed(2)}</p>
                                </div>
                            </div>
                            <hr className='text-black h-5 mt-10' />
                            <p className='text-center'>Thank you for your business!</p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default InvoiceSummary;