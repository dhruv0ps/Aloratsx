import React, { useEffect, useState } from 'react';
import { MdEdit, MdImageNotSupported } from 'react-icons/md';
import { Button, Select, TextInput } from 'flowbite-react';
import { useNavigate } from 'react-router-dom';
import Loading from '../../util/Loading';
import { FaChevronLeft } from 'react-icons/fa6';
import { ProductWithData as Product } from '../../config/models/product';
import { productApis } from '../../config/apiRoutes/productRoutes';

const ViewProducts: React.FC = () => {
    const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [searchTerm, setSearchTerm] = useState<string>('');
    const [selectedCategory, setSelectedCategory] = useState<string>('');
    const [categories, setCategories] = useState<Set<string>>(new Set());
    const [page, setPage] = useState<number>(1);
    const [limit, setLimit] = useState<number>(10);
    const [totalPages, setTotalPages] = useState<number>(1);

    const navigate = useNavigate()

    useEffect(() => {
        fetchProducts();
    }, [page, limit]);

    const fetchProducts = async () => {
        setLoading(true);
        try {
            const response = await productApis.getAllProducts({
                page,
                limit,
                filters: { search: searchTerm, category: selectedCategory }
            });
            if (response.status) {
                setTotalPages(response.data.totalPages);
                setFilteredProducts(response.data.products);
                let resCat = await productApis.GetCategories()
                resCat.status && setCategories(response.data.map((category: { name: string, _id: string }) => category.name));
                // setCategories(resCat.data);
            }
        } catch (err: any) {
        } finally {
            setLoading(false);
        }
    };
    const handlePageChange = (newPage: number) => {
        setPage(newPage);
    };
    const handleLimitChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setLimit(Number(e.target.value));
    };
    const handleEdit = (productId: string) => {
        navigate(`/products/manage/${productId}`);
    };

    if (loading) return <Loading />;
    // if (error) return <div>{error}</div>;

    return (
        <div className="mx-auto p-4 lg:px-8">
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold ">Products Listing</h2>
                <Button color='green' onClick={() => navigate("/products/add")}>
                    <span className='flex gap-2 items-center'>Add Products</span>
                </Button>
            </div>
            <div className='flex gap-6 justify-between items-end mb-6'>
                <TextInput
                    type="text"
                    placeholder="Search by name or SKU"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    className="flex-1"
                />
                <Select value={selectedCategory}
                    onChange={e => setSelectedCategory(e.target.value)} >
                    <option value="">All Categories</option>
                    {[...categories].map(category => (
                        <option key={category} value={category}>{category}</option>
                    ))}
                </Select>
                <label className="flex flex-col text-gray-500">
                    <span className="text-sm">Items per page</span>
                    <select
                        value={limit}
                        onChange={handleLimitChange}
                        className="rounded-md border-gray-300 py-2 px-4 focus:ring focus:ring-purple-200 transition"
                    >
                        <option value={10}>10</option>
                        <option value={20}>20</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                    </select>
                </label>
                <Button color={'purple'} onClick={fetchProducts}>Apply</Button>
            </div>
            <div className="overflow-x-auto">
                {filteredProducts.length > 0 ? <table className="min-w-full bg-white">
                    <thead>
                        <tr className="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                            <th className="py-3 px-6 text-left">Image</th>
                            <th className="py-3 px-6 text-left">Name</th>
                            <th className="py-3 px-6 text-left">Category</th>
                            <th className="py-3 px-6 text-left">SKU</th>
                            <th className="py-3 px-6 text-left">Stock</th>
                            <th className="py-3 px-6 text-left">Color</th>
                            <th className="py-3 px-6 text-right">Price</th>
                            <th className="py-3 px-6 text-center">Status</th>
                            <th className="py-3 px-6 text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="text-gray-600 text-sm font-light">
                        {filteredProducts.flatMap(product =>
                            product.children.map(child => (
                                <tr key={child.SKU} className="border-b border-gray-200 hover:bg-gray-100">
                                    <td className="py-3 px-6 text-left whitespace-nowrap">
                                        <div className="w-12 h-12 flex items-center justify-center bg-gray-100 rounded-md overflow-hidden">
                                            {child.image
                                                ? <img src={`${import.meta.env.VITE_BASE_IMAGE_URL}/${child.image.path}`} alt={child.name} className="object-contain w-full h-full" />
                                                : <MdImageNotSupported className="text-gray-400 text-2xl" />}
                                        </div>
                                    </td>
                                    <td className="py-3 px-6 text-left">{product.name} - {child.name}</td>
                                    <td className="py-3 px-6 text-left">{product.category.name}</td>
                                    <td className="py-3 px-6 text-left">{child.SKU}</td>
                                    <td className="py-3 px-6 text-left">{child.stock}</td>
                                    <td className="py-3 px-6 text-left"><div className="flex items-center gap-x-5">
                                        <div className="flex items-center space-x-4">
                                            <input
                                                type="color"
                                                id="colorPicker"
                                                value={child.color.hexCode}
                                                className="w-8 h-8 p-0 border-0 rounded-lg cursor-pointer"
                                            />
                                            <span className="text-gray-700">{child.color.name}</span>
                                        </div>
                                    </div></td>
                                    <td className="py-3 px-6 text-right">${child.selling_price}</td>
                                    <td className="py-3 px-6 text-center">
                                        <span className={`bg-${child.status === 'IN STOCK' ? 'green' : 'red'}-200 text-${child.status === 'IN STOCK' ? 'green' : 'red'}-600 py-1 text-nowrap px-3 rounded-full text-xs`}>
                                            {child.status}
                                        </span>
                                    </td>
                                    <td className="py-3 px-6 text-center">
                                        <button
                                            onClick={() => handleEdit(product._id)}
                                            className="bg-indigo-500 text-white px-3 py-1 rounded hover:bg-indigo-600 transition duration-200 flex items-center justify-center"
                                        >
                                            <MdEdit className="mr-1" /> Edit
                                        </button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table> : <p>No Products Found</p>}
            </div>
            <div className='flex items-center justify-center'>

                <Button color="gray" disabled={page === 1} onClick={() => handlePageChange(page - 1)}>
                    Previous
                </Button>
                <span className="mx-4">Page {page} of {totalPages}</span>
                <Button color="gray" disabled={page === totalPages || totalPages === 0} onClick={() => handlePageChange(page + 1)}>
                    Next
                </Button>
            </div>
        </div>
    );
};

export default ViewProducts;
