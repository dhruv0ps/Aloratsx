import React, { useEffect, useState } from 'react';
import { toast } from 'react-toastify';
import { useNavigate, useParams } from 'react-router-dom';
import { Button, Table, TextInput, Select, FileInput } from 'flowbite-react';
import { MdDelete, MdImageNotSupported } from 'react-icons/md';
import { FaChevronLeft, FaPencil } from 'react-icons/fa6';
import Loading from '../../util/Loading';
import { ProductFormState } from '../../config/models/product';
import { Child } from '../../config/models/Child';
import { productApis } from '../../config/apiRoutes/productRoutes';
import { Category } from '../../config/models/category';
import AutocompleteCategory from '../../util/AutoCompleteCategory';
import { Color } from '../../config/models/color';
import AutocompleteColor from '../../util/AutoCompleteColor';

const MAX_FILE_SIZE = 1 * 1024 * 1024;

const ProductForm: React.FC = () => {
    const [formState, setFormState] = useState<ProductFormState>({
        name: '',
        category: '',
        ID: '',
        children: [],
        heroImage: null,
        heroImageUrl: ''
    });

    const [childState, setChildState] = useState<Child>({
        SKU: '',
        name: '',
        color: { name: "Black", hexCode: "#000000", status: "ACTIVE" },
        selling_price: 0,
        cost_price: 0,
        weight: { value: 0, unit: 'lb' },
        status: 'IN STOCK',
        image: null,
        imageUrl: "",
        stock: 0,
        isActive: true
    });

    const [loading, setLoading] = useState<boolean>(false);
    const [selectedCategory, setSelectedCategory] = useState<Category>();
    const [selectedColor, setSelectedColor] = useState<Color>();

    const params = useParams<{ id?: string }>();
    const { id } = params;
    const navigate = useNavigate();

    useEffect(() => {
        if (id) {
            fetchProductDetails(id);
        }
    }, [id]);



    const fetchProductDetails = async (productId: string) => {
        setLoading(true);
        try {
            const response = await productApis.getProductById(productId);
            if (response.status) {
                setFormState({
                    ...response.data,
                    category: response.data.category._id,
                    heroImageUrl: `${import.meta.env.VITE_BASE_IMAGE_URL}/${response.data.heroImage}`
                });
                setSelectedCategory(response.data.category)
            }
        } catch (error: any) {
            console.error(error.response.err);
        } finally {
            setLoading(false);
        }
    };

    // const fetchNextProductId = async () => {
    //     try {
    //         const response = await productApis.nextProductID();
    //         if (response.status) {
    //             let nextId = response.data.nextProductId;
    //             setFormState((prevState) => ({ ...prevState, ID: nextId }));
    //             setChildState((prev) => ({ ...prev, SKU: `${nextId}CH${formState.children.length + 1}` }));
    //         }
    //     } catch (error) {
    //         toast.error('Failed to fetch next product ID');
    //     }
    // };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        let { name, value } = e.target;
        if (typeof value === "string" && name !== 'category')
            value = value.toUpperCase();
        setFormState({ ...formState, [name]: value });
    };

    const handleChildInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        let { name, value } = e.target;
        if (name === 'weight.value' || name === 'weight.unit') {
            const [_, subfield] = name.split('.');
            setChildState((prevState) => ({
                ...prevState,
                weight: {
                    ...prevState.weight,
                    [subfield]: subfield === 'value' ? parseFloat(value) : value
                }
            }));
        } else {
            setChildState((prevState) => ({
                ...prevState,
                [name]: name === 'selling_price' || name === 'cost_price' || name === 'stock' ? parseFloat(value) : value
            }));
        }
    };

    const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>, isHeroImage: boolean = false) => {
        const file = e.target.files?.[0];

        if (file && file.size > MAX_FILE_SIZE) {
            toast.error("File size exceeds 1MB.");
        } else if (file) {
            const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!allowedTypes.includes(file.type)) {
                toast.error("Only JPEG, PNG, and GIF images are allowed.");
                return;
            }
            if (isHeroImage) {
                setFormState(prev => ({ ...prev, heroImage: file, heroImageUrl: URL.createObjectURL(file) }));
            } else {
                setChildState(prev => ({ ...prev, image: file, imageUrl: URL.createObjectURL(file) }));
            }
        }
    };

    const addChild = () => {
        if (!childState.SKU || !childState.color || !childState.cost_price || !childState.name || !childState.selling_price) {
            toast.info("Please fill the required fields before adding");
            return;
        }
        let existing = formState.children.findIndex(child => child.SKU === childState.SKU);
        if (existing > -1) {
            let cloneFormStateChildren = [...formState.children];
            cloneFormStateChildren[existing] = childState;
            setFormState({ ...formState, children: cloneFormStateChildren });
        } else {
            setFormState({ ...formState, children: [...formState.children, childState] });
        }
        setChildState({
            SKU: `${formState.ID}CH${formState.children.length + 2}`,
            name: '',
            color: { name: "Black", hexCode: "#000000", status: "ACTIVE" },
            selling_price: 0,
            cost_price: 0,
            weight: { value: 0, unit: 'lb' },
            status: 'IN STOCK',
            image: null,
            imageUrl: "",
            stock: 0,
            isActive: true
        });
    };

    const removeChild = (SKU: string) => {
        setFormState({ ...formState, children: formState.children.map(child => child.SKU === SKU ? { ...child, isActive: false } : child) });
    };
    const restoreChild = (SKU: string) => {
        setFormState({ ...formState, children: formState.children.map(child => child.SKU === SKU ? { ...child, isActive: true } : child) });
    };

    const editChild = (child: Child) => {
        setChildState(child);
    };
    const handleColorSelect = (color: Color) => {
        setChildState(prev => ({ ...prev, color: color }))
        setSelectedColor(color)
    }
    const handleCategorySelect = (category: Category) => {
        setFormState(prev => ({ ...prev, category: category._id ?? "" }))
        setSelectedCategory(category)
    }
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        try {
            const formData = new FormData();
            console.log("FormState:", formState);

            // Append main product data
            const productData = {
                name: formState.name,
                category: formState.category,
                ID: formState.ID,
            };
            formData.append('productData', JSON.stringify(productData));

            // Append children data
            const childrenDataArray = formState.children.map(child => ({
                ...child,
                image: undefined  // Remove image from JSON data
            }));
            formData.append('childrenData', JSON.stringify(childrenDataArray));

            // Append hero image
            if (formState.heroImage instanceof File) {
                // If it's a new file, append it
                formData.append('heroImage', formState.heroImage, 'heroImage');
            } else if (typeof formState.heroImage === 'string') {
                // If it's an existing image path, include it in the productData
                const updatedProductData = {
                    ...JSON.parse(formData.get('productData') as string),
                    heroImage: formState.heroImage
                };
                formData.set('productData', JSON.stringify(updatedProductData));
            }

            // Append children images
            formState.children.forEach((child, index) => {
                if (child.image instanceof File) {
                    formData.append(`childrenImages`, child.image, `${child.SKU}`);
                } else if (typeof child.image === 'object' && child.image !== null) {
                    // If it's an existing image object, include it in the childrenData
                    childrenDataArray[index].image = child.image;
                }
            });
            // Update childrenData with any existing image objects
            formData.set('childrenData', JSON.stringify(childrenDataArray));

            // Log the contents of FormData
            for (let [key, value] of formData.entries()) {
                console.log(key, value);
            }

            let res;
            if (id) {
                res = await productApis.updateProduct(id, formData);
            } else {
                res = await productApis.createProduct(formData);
            }

            if (res.status) {
                id ? toast.success("Product successfully updated.") : toast.success("Product successfully created.");
                navigate('/products');
            } else {
                throw new Error(res.err || "An error occurred");
            }
        } catch (error) {
            console.error("Error in handleSubmit:", error);
            // toast.error(error.message || "Something went wrong.");
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <Loading />;
    // if (bulkUpload) return <BulkUpload setLoading={setLoading} setBulkUpload={setBulkUpload} isSupplier={false} />;

    return (
        <form onSubmit={handleSubmit} className="max-w-5xl mx-auto bg-white p-8 shadow-md rounded-lg">
            <div className='mb-6 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold ">{id ? "Edit Product" : "Add Product"}</h2>
                <p></p>
            </div>

            <div className="mb-4">
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Product Name:</label>
                <TextInput
                    id="name"
                    name="name"
                    value={formState.name}
                    onChange={handleInputChange}
                    required
                />
            </div>

            <div className="mb-4">
                <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Category:</label>
                <AutocompleteCategory
                    onSelect={(category: Category) => handleCategorySelect(category)}
                    value={selectedCategory}
                />
            </div>

            <div className="mb-4">
                <label htmlFor="ID" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Product ID:</label>
                <TextInput
                    id="ID"
                    name="ID"
                    value={formState.ID}
                    onChange={handleInputChange}
                    required
                />
            </div>

            <div className="mb-4">
                <label htmlFor="heroImage" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Hero Image:</label>
                <FileInput
                    id="heroImage"
                    accept="image/*"
                    onChange={(e) => handleFileInputChange(e, true)}
                />
                {formState.heroImageUrl && (
                    <img src={formState.heroImageUrl} alt="Hero" className="mt-2 h-40 object-cover" />
                )}
            </div>

            <hr className='my-6' />

            <div className="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="SKU" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>SKU:</label>
                    <TextInput
                        id="SKU"
                        name="SKU"
                        value={childState.SKU}
                        onChange={handleChildInputChange}
                        required={formState.children.length < 1}
                    />
                </div>
                <div>
                    <label htmlFor="child_name" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Child Name:</label>
                    <TextInput
                        id="child_name"
                        name="name"
                        value={childState.name}
                        onChange={handleChildInputChange}
                        required={formState.children.length < 1}
                    />
                </div>
                <div>
                    <label htmlFor="color" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Color:</label>
                    <AutocompleteColor
                        onSelect={(color) => handleColorSelect(color)}
                        value={selectedColor}
                    />
                </div>
                <div>
                    <label htmlFor="selling_price" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Selling Price:</label>
                    <TextInput
                        id="selling_price"
                        name="selling_price"
                        type="number"
                        min={0}
                        value={childState.selling_price}
                        onChange={handleChildInputChange}
                        required={formState.children.length < 1}
                    />
                </div>
                <div>
                    <label htmlFor="cost_price" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Cost Price:</label>
                    <TextInput
                        id="cost_price"
                        name="cost_price"
                        type="number"
                        min={0}
                        value={childState.cost_price}
                        onChange={handleChildInputChange}
                        required={formState.children.length < 1}
                    />
                </div>
                <div>
                    <label htmlFor="weight.value" className="block text-sm font-medium text-gray-700 mb-2">Weight:</label>
                    <div className="flex">
                        <TextInput
                            id="weight.value"
                            name="weight.value"
                            type="number"
                            min={0}
                            value={childState.weight.value}
                            onChange={handleChildInputChange}
                            className="flex-grow"
                        />
                        <Select
                            id="weight.unit"
                            name="weight.unit"
                            value={childState.weight.unit}
                            onChange={handleChildInputChange}
                            className="ml-2 w-24"
                        >
                            <option value="lb">lb</option>
                            <option value="kg">kg</option>
                        </Select>
                    </div>
                </div>
                <div>
                    <label htmlFor="status" className="block text-sm font-medium text-gray-700 mb-2"><span className='text-red-500'>*</span>Status:</label>
                    <Select
                        id="status"
                        name="status"
                        value={childState.status}
                        onChange={handleChildInputChange}
                        required={formState.children.length < 1}
                    >
                        <option value="IN STOCK">In Stock</option>
                        <option value="LOW STOCK">Low Stock</option>
                        <option value="VERY LOW IN STOCK">Very Low in Stock</option>
                        <option value="OUT OF STOCK (WITH ESTIMATED DATE)">Out of Stock (with Estimated Date)</option>
                        <option value="DISCONTINUED">Discontinued</option>
                    </Select>
                </div>
                {/* <div>
                    <label htmlFor="stock" className="block text-sm font-medium text-gray-700 mb-2">Stock:</label>
                    <TextInput
                        id="stock"
                        name="stock"
                        type="number"
                        min={0}
                        value={childState.stock}
                        onChange={handleChildInputChange}
                    />
                </div> */}
                <div className="col-span-2">
                    <label htmlFor="childImage" className="block text-sm font-medium text-gray-700 mb-2">Child Image:</label>
                    <FileInput
                        id="childImage"
                        accept="image/*"
                        onChange={handleFileInputChange}
                    />
                    {childState.imageUrl && (
                        <img src={childState.imageUrl} alt="Child" className="mt-2 h-40 object-cover" />
                    )}
                </div>
                <div className="flex justify-end col-span-full">
                    <Button color="success" onClick={addChild}>
                        {childState.SKU ? 'Update Child' : 'Add Child'}
                    </Button>
                </div>
            </div>

            <div className="overflow-x-auto">
                <Table className="mb-4">
                    <Table.Head>
                        <Table.HeadCell>SKU</Table.HeadCell>
                        <Table.HeadCell>Name</Table.HeadCell>
                        <Table.HeadCell>Color</Table.HeadCell>
                        <Table.HeadCell>Selling Price</Table.HeadCell>
                        <Table.HeadCell>Cost Price</Table.HeadCell>
                        <Table.HeadCell>Weight</Table.HeadCell>
                        <Table.HeadCell>Status</Table.HeadCell>
                        <Table.HeadCell>Stock</Table.HeadCell>
                        <Table.HeadCell>Image</Table.HeadCell>
                        <Table.HeadCell>Actions</Table.HeadCell>
                    </Table.Head>
                    <Table.Body>
                        {formState.children.filter(child => child.isActive).map((child, index) => (
                            <Table.Row key={index}>
                                <Table.Cell>{child.SKU}</Table.Cell>
                                <Table.Cell>{child.name}</Table.Cell>
                                <Table.Cell>
                                    <div className="w-6 h-6 rounded-full border border-black" style={{ backgroundColor: child.color.hexCode }}></div>
                                </Table.Cell>
                                <Table.Cell>{child.selling_price}</Table.Cell>
                                <Table.Cell>{child.cost_price}</Table.Cell>
                                <Table.Cell>{`${child.weight.value} ${child.weight.unit}`}</Table.Cell>
                                <Table.Cell>{child.status}</Table.Cell>
                                <Table.Cell>{child.stock}</Table.Cell>
                                <Table.Cell>
                                    {child.imageUrl ? (
                                        <img className='w-20 h-20 object-contain' src={child.imageUrl} alt="Child" />
                                    ) : (
                                        <MdImageNotSupported className='h-7 w-7' />
                                    )}
                                </Table.Cell>
                                <Table.Cell className='flex items-center justify-between'>
                                    <Button
                                        color={'success'}
                                        size="xs"
                                        className='mx-1'
                                        onClick={() => editChild(child)}
                                    >
                                        <FaPencil />
                                    </Button>
                                    <Button
                                        color="failure"
                                        size="xs"
                                        className='mx-1'
                                        onClick={() => removeChild(child.SKU)}
                                    >
                                        <MdDelete />
                                    </Button>
                                </Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>
            </div>

            <div className="overflow-x-auto">
                {formState.children.some(child=>child.isActive)?<></>:<Table className="mb-4">
                    <Table.Head>
                        <Table.HeadCell>SKU</Table.HeadCell>
                        <Table.HeadCell>Name</Table.HeadCell>
                        <Table.HeadCell>Color</Table.HeadCell>
                        <Table.HeadCell>Selling Price</Table.HeadCell>
                        <Table.HeadCell>Cost Price</Table.HeadCell>
                        <Table.HeadCell>Weight</Table.HeadCell>
                        <Table.HeadCell>Status</Table.HeadCell>
                        <Table.HeadCell>Stock</Table.HeadCell>
                        <Table.HeadCell>Image</Table.HeadCell>
                        <Table.HeadCell>Actions</Table.HeadCell>
                    </Table.Head>
                    <Table.Body>
                        {formState.children.filter(child => !child.isActive).map((child, index) => (
                            <Table.Row key={index}>
                                <Table.Cell>{child.SKU}</Table.Cell>
                                <Table.Cell>{child.name}</Table.Cell>
                                <Table.Cell>
                                    <div className="w-6 h-6 rounded-full border border-black" style={{ backgroundColor: child.color.hexCode }}></div>
                                </Table.Cell>
                                <Table.Cell>{child.selling_price}</Table.Cell>
                                <Table.Cell>{child.cost_price}</Table.Cell>
                                <Table.Cell>{`${child.weight.value} ${child.weight.unit}`}</Table.Cell>
                                <Table.Cell>{child.status}</Table.Cell>
                                <Table.Cell>{child.stock}</Table.Cell>
                                <Table.Cell>
                                    {child.imageUrl ? (
                                        <img className='w-20 h-20 object-contain' src={child.imageUrl} alt="Child" />
                                    ) : (
                                        <MdImageNotSupported className='h-7 w-7' />
                                    )}
                                </Table.Cell>
                                <Table.Cell className='flex items-center justify-between'>
                                    {/* <Button
                                        color={'success'}
                                        size="xs"
                                        className='mx-1'
                                        onClick={() => editChild(child)}
                                    >
                                        <FaPencil />
                                    </Button> */}
                                    <Button
                                        color="success"
                                        size="xs"
                                        className='mx-1'
                                        onClick={() => restoreChild(child.SKU)}
                                    >
                                        Restore
                                    </Button>
                                </Table.Cell>
                            </Table.Row>
                        ))}
                    </Table.Body>
                </Table>}
            </div>

            <div className="flex justify-end">
                <Button color="blue" type="submit">
                    {id ? "Update Product" : "Create Product"}
                </Button>
            </div>
        </form>
    );
};

export default ProductForm;