import { useState, useEffect } from 'react';
import { Button, Modal, Table } from 'flowbite-react';
import { toast } from 'react-toastify';
import { productApis } from '../../config/apiRoutes/productRoutes';
import showConfirmationModal from '../../util/confirmationUtil';
import { Category } from '../../config/models/category';
import { useNavigate } from 'react-router-dom';
import { FaChevronLeft } from 'react-icons/fa6';


const CategoryManager: React.FC = () => {
    const [categories, setCategories] = useState<Category[]>([]);
    const [deletedCategories, setDeletedCategories] = useState<Category[]>([]);
    const [showModal, setShowModal] = useState(false);
    const [currentCategory, setCurrentCategory] = useState<Category | null>(null);
    const [formData, setFormData] = useState({ name: '', description: '', image: null as File | null, status: 'ACTIVE' });
    const navigate = useNavigate()

    const fetchCategories = async () => {
        try {
            const res = await productApis.GetCategories();
            if (res.status) {
                setCategories(res.data.filter((cat: Category) => cat.status === 'ACTIVE'));
                setDeletedCategories(res.data.filter((cat: Category) => cat.status === 'DELETED'));
            }
        } catch (error) {
            console.error('Error fetching categories:', error);
        }
    };

    useEffect(() => {
        fetchCategories();
    }, []);

    const handleSubmit = async () => {
        const formDataToSend = new FormData();
        formDataToSend.append('name', formData.name);
        formDataToSend.append('description', formData.description);
        if (formData.image) {
            formDataToSend.append('image', formData.image); // Append image only if selected
        }

        if (currentCategory) {
            // Update category
            try {
                const res = await productApis.UpdateCategories(currentCategory._id ?? '', formDataToSend);
                if (res.status) {
                    toast.success('Category successfully updated.');
                    setShowModal(false);
                    fetchCategories();
                }
            } catch (error) {
                console.error('Error updating category:', error);
            }
        } else {
            // Add new category
            try {
                const res = await productApis.AddCategory(formDataToSend);
                if (res.status) {
                    toast.success('Category successfully added.');
                    setShowModal(false);
                    fetchCategories();
                }
            } catch (error) {
                console.error('Error adding category:', error);
            }
        }
    };

    const handleDelete = async (category: Category) => {
        const confirmed = await showConfirmationModal('Are you sure you want to delete this category?');
        if (!confirmed) return;
        try {
            const res = await productApis.UpdateCategories(category._id ?? '', { ...category, status: 'DELETED' });
            if (res.status) {
                toast.success('Category successfully deleted.');
                fetchCategories();
            }
        } catch (error) {
            console.error('Error deleting category:', error);
        }
    };

    const handleRestore = async (category: Category) => {
        const confirmed = await showConfirmationModal('Are you sure you want to restore this category?');
        if (!confirmed) return;
        try {
            const res = await productApis.UpdateCategories(category._id ?? '', { ...category, status: 'ACTIVE' });
            if (res.status) {
                toast.success('Category successfully restored.');
                fetchCategories();
            }
        } catch (error) {
            console.error('Error restoring category:', error);
        }
    };

    const openModalForEdit = (category: Category) => {
        setCurrentCategory(category);
        setFormData({
            name: category.name,
            description: category.description,
            image: null, // Will only allow replacing image, not showing the current one
            status: category.status,
        });
        setShowModal(true);
    };

    const openModalForAdd = () => {
        setCurrentCategory(null);
        setFormData({ name: '', description: '', image: null, status: 'ACTIVE' });
        setShowModal(true);
    };

    const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files) {
            setFormData({ ...formData, image: e.target.files[0] });
        }
    };

    return (
        <div className="max-w-7xl mx-auto p-5 rounded-lg bg-white">
            <div className='mb-12 flex items-center justify-between'>
                <Button color='gray' onClick={() => navigate(-1)}>
                    <span className='flex gap-2 items-center'><FaChevronLeft />Back</span>
                </Button>
                <h2 className="text-2xl font-semibold ">Manage Categories</h2>
                <Button color="green" onClick={openModalForAdd}>Add New Category</Button>
            </div>

            <div className="mt-5">
                <h3 className="font-bold mb-2">Active Categories</h3>
                <div className="overflow-x-auto">
                    <Table>
                        <Table.Head>

                            <Table.HeadCell>Name</Table.HeadCell>
                            <Table.HeadCell>Description</Table.HeadCell>
                            <Table.HeadCell>Image</Table.HeadCell>
                            <Table.HeadCell className='justify-end flex'>Action</Table.HeadCell>

                        </Table.Head>
                        <Table.Body>
                            {categories.map((category) => (
                                <Table.Row key={category._id}>
                                    <Table.Cell>{category.name}</Table.Cell>
                                    <Table.Cell>{category.description}</Table.Cell>
                                    <Table.Cell>
                                        <img src={`${import.meta.env.VITE_BASE_IMAGE_URL}/${category.image}`} alt={category.name} className="w-12 h-12 object-cover" />
                                    </Table.Cell>
                                    <Table.Cell className='flex gap-x-3 items-center justify-end'>
                                        <Button size={'xs'} color="blue" onClick={() => openModalForEdit(category)}>Edit</Button>
                                        <Button size={'xs'} color="failure" onClick={() => handleDelete(category)}>Delete</Button>
                                    </Table.Cell>
                                </Table.Row>
                            ))}
                        </Table.Body>
                    </Table>
                </div>
            </div>

            <div className="mt-5">
                <h3 className="font-bold mb-2">Deleted Categories</h3>
                <div className="overflow-x-auto">
                    <Table>
                        <Table.Head>

                            <Table.HeadCell>Name</Table.HeadCell>
                            <Table.HeadCell>Description</Table.HeadCell>
                            <Table.HeadCell>Image</Table.HeadCell>
                            <Table.HeadCell className='justify-end flex'>Action</Table.HeadCell>

                        </Table.Head>
                        <Table.Body>
                            {deletedCategories.map((category) => (
                                <Table.Row key={category._id}>
                                    <Table.Cell>{category.name}</Table.Cell>
                                    <Table.Cell>{category.description}</Table.Cell>
                                    <Table.Cell>
                                        <img src={`${import.meta.env.VITE_BASE_IMAGE_URL}/${category.image}`} alt={category.name} className="w-12 h-12 object-cover" />
                                    </Table.Cell>
                                    <Table.Cell className='justify-end flex'>
                                        <Button size={'xs'} color="success" onClick={() => handleRestore(category)}>Restore</Button>
                                    </Table.Cell>
                                </Table.Row>
                            ))}
                        </Table.Body>
                    </Table>
                </div>
            </div>

            <Modal show={showModal} onClose={() => setShowModal(false)}>
                <Modal.Header>{currentCategory ? 'Edit Category' : 'Add Category'}</Modal.Header>
                <Modal.Body>
                    <form onSubmit={(e) => { e.preventDefault(); handleSubmit(); }}>
                        <div className="mb-4">
                            <label htmlFor="name" className="block text-gray-700 font-semibold mb-1">Category Name:</label>
                            <input
                                type="text"
                                id="name"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                required
                                className="border border-gray-300 rounded-lg p-2 w-full"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="description" className="block text-gray-700 font-semibold mb-1">Description:</label>
                            <textarea
                                id="description"
                                value={formData.description}
                                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                required
                                className="border border-gray-300 rounded-lg p-2 w-full"
                            />
                        </div>
                        <div className="mb-4">
                            <label htmlFor="image" className="block text-gray-700 font-semibold mb-1">Category Image:</label>
                            <input
                                type="file"
                                id="image"
                                accept="image/*"
                                onChange={handleImageChange}
                                className="border border-gray-300 rounded-lg p-2 w-full"
                            />
                        </div>
                        <Button type="submit" color="green">{currentCategory ? 'Update' : 'Add'} Category</Button>
                    </form>
                </Modal.Body>
            </Modal>
        </div>
    );
};

export default CategoryManager;
