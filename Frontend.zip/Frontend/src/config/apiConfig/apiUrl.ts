const base = "http://localhost:3000/api"
// const base = "http://3.99.86.156:3000/api"

export const apiUrl = {
    color: `${base}/colors`,
    Category: `${base}/categories`,
    product: `${base}/product`,
    taxslab: `${base}/taxslab`,
    tempdealer: `${base}/tempdealer`,
    approveddealer: `${base}/dealers`,
    order: `${base}/orders`,
    getOrder: `${base}/getorders`,
    logindealer: `${base}/logindealer`,
    packingSlip: `${base}/packing`,
    invoice: `${base}/invoice`,
    transaction: `${base}/transaction`,
}