
import { apiUrl } from "../apiConfig/apiUrl";
import { axiosRequest } from "../apiConfig/axiosRequest";

const getAllProducts = async (body:any) => {
    return await axiosRequest.post<any>(`${apiUrl.product}`,body)
}
const getProductById = async (param: any) => {
    return await axiosRequest.get<any>(`${apiUrl.product}/${param}`)
}
const updateProduct = async (param: any, body: any) => {
    return await axiosRequest.post<any>(`${apiUrl.product}/${param}`, body)
}
const createProduct = async (body: any) => {
    return await axiosRequest.post<any>(`${apiUrl.product}/add`, body)
}
const AddColor = async (body: any) => {
    return await axiosRequest.post<any>(apiUrl.color, body)
}
const GetColors = async () => {
    return await axiosRequest.get<any>(apiUrl.color)
}
const UpdateColors = async (id: string, body: any) => {
    return await axiosRequest.put<any>(`${apiUrl.color}/${id}`, body)
}
const AddCategory = async (body: any) => {
    return await axiosRequest.post<any>(apiUrl.Category, body)
}
const GetCategories = async () => {
    return await axiosRequest.get<any>(apiUrl.Category)
}
const UpdateCategories = async (id: string, body: any) => {
    return await axiosRequest.put<any>(`${apiUrl.Category}/${id}`, body)
}


export const productApis = {
    AddColor,
    GetColors,
    UpdateColors,
    GetCategories,
    AddCategory,
    UpdateCategories,
    getAllProducts,
    createProduct,
    updateProduct,
    getProductById
}