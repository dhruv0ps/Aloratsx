
import axios from 'axios';
import { apiUrl } from '../apiConfig/apiUrl'; 

const getAllOrders = async (data : id ) => {
    return await axios.post(`${apiUrl.order}/dealer` , data);
};

const getAllDealers = async () => {
    return await axios.get(`${apiUrl.approveddealer}`); 
};

const getAllInvoices = async () => {
    return await axios.get(`${apiUrl.invoice}`);
};

const addInvoice = async (data: any) => {
    return await axios.post(`${apiUrl.invoice}/add`, data); 
};

const getAllTaxSlabs = async() => {
    return await axios.get(apiUrl.taxslab);
}

export const invoiceApis = {
    getAllOrders,
    getAllDealers,
    getAllInvoices,
    addInvoice,
    getAllTaxSlabs,
};