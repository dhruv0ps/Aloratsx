import { apiUrl } from "../apiConfig/apiUrl";
import { axiosRequest } from "../apiConfig/axiosRequest";
import { PackingSlip } from "../models/PackingSlip"; // Import the PackingSlip model

// Fetch all packing slips without pagination
const getAllPackingSlips = async () => {
    return await axiosRequest.get<{ status: boolean; data: PackingSlip[] }>(`${apiUrl.packingSlip}`);
};

// Fetch a packing slip by ID
const getPackingSlipById = async (id: string) => {
    return await axiosRequest.get<{ status: boolean; data: PackingSlip }>(`${apiUrl.packingSlip}/${id}`);
};

// Fetch a packing slip by ID
const getPackingSlipBypackingId = async (body : PackingSlip) => {
    return await axiosRequest.get<{ status: boolean; data: PackingSlip }>(`${apiUrl.packingSlip}/packing` ,body);
};

// Create a new packing slip
const createPackingSlip = async (body: any) => {
    return await axiosRequest.post<{ status: boolean; data: PackingSlip }>(`${apiUrl.packingSlip}/add`, body);
};

const getPackingSlipByOrderId = async(body : any) => {
    return await axiosRequest.post<{ status : boolean ; data: PackingSlip }>(`${apiUrl.order}/po`, body);
}

// Export the packing slip API functions
export const packingSlipApis = {
    getAllPackingSlips,
    getPackingSlipById,
    createPackingSlip,
    getPackingSlipBypackingId,
    getPackingSlipByOrderId,
};
