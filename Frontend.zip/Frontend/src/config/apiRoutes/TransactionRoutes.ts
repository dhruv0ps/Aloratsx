// api/TransactionRoutes.ts
import axios from 'axios';
import { apiUrl } from '../apiConfig/apiUrl'; 
import { Transaction } from '../models/Transaction'; 

const getAllTransactions = async () => {
    return await axios.get<Transaction[]>(`${apiUrl.transaction}`); 
};

const addTransaction = async (data: Transaction) => {
    return await axios.post(`${apiUrl.transaction}/create`, data); 
};

const deleteTransaction = async ( data : Transaction) => {
      return await axios.delete(`${apiUrl.transaction}/delete`, data); 
}

const updateTransaction = async(data : any) => {
    return await axios.put(`${apiUrl.transaction}/update/${data}`);
}

const getAllDealers = async () => {
    return await axios.get<Transaction[]>(`${apiUrl.approveddealer}`);
}

const getInvoiceList = async (data : id) => {
    return await axios.post<Transaction[]>(`${apiUrl.invoice}/list`,data)
}

export const transactionApis = {
    getAllTransactions,
    getAllDealers,
    addTransaction,
    getInvoiceList,
    updateTransaction,
    deleteTransaction,
};