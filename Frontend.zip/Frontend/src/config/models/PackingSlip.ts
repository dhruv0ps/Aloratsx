export interface PackingSlipItem {
    id: string; // Unique identifier for the item
    itemNo: string; // Item number
    name?: string; // Optional name of the item
    description: string; // Description of the item
    quantity: number; // Quantity of the item
    item?: string; // Optional additional data for the item
}

export interface PackingSlip {
    _id: string;
    packingSlipID: string; 
    qty: string;
    date:string;
    description:string;
    receivedSign: string; 
    itemName:string;
    itemNo:string;
    items: PackingSlipItem[]; 
}

export interface PackingSlipFormState {
    packingID: string; // Packing slip ID
    receivedSign?: File; // Optional file for received sign
    notes?: string; // Optional notes for the packing slip
}

export interface PackingSlipFormWithData extends Omit<PackingSlipFormState, 'items'> {
    items: PackingSlipItem[]; // Items with additional data
}

export interface PackingSlipWithData extends Omit<PackingSlip, 'items'> {
    items: PackingSlipItem[]; // Items with additional data
}