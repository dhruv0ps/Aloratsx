import { Category } from "./category";
import { Child, ChildWithData } from "./Child";

export interface Product {
    _id: string;
    name: string;
    category: Category;
    ID: string;
    children: Child[];
    createdAt: string;
    updatedAt: string;
    __v: number;
    // quantity: number;
}

export interface ProductFormState {
    name: string;
    category: string;
    ID: string;
    children: Child[];
    heroImage: File | null;
    heroImageUrl: string;
}

export interface ProductFormWithData extends Omit<ProductFormState, 'children'> {
    children: ChildWithData[]
}

export interface ProductWithData extends Omit<Product, 'children'> {
    children: ChildWithData[]
}