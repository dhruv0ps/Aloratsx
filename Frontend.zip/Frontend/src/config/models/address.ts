export interface Address {
  buzz?: string;
  unit?: string;
  address: string;
  longitude: string;
  latitude: string;
}

