// // models/Invoice.ts
// export interface InvoiceItem {
//     id: string;
//     itemNo: string;
//     description: string;
//     price: number;
//     quantity: number;
// }

// export interface Order {
//     id: string;
//     name: string;
//     items: InvoiceItem[];
// }

// export interface Dealer {
//     id: string;
//     name: string;
// }

// models/Invoice.ts
// export interface InvoiceItem {
//     id: string;
//     itemNo: string;
//     price: number;
//     quantity: number;
// }

// export interface Order {
//     id: string;
//     name: string;
//     items: InvoiceItem[];
//     dealerId: string
// }

// export interface Dealer {
//     id: string;
//     name: string;
// }
// models/Invoice.ts
// models/Invoice.ts
// models/Invoice.ts
export interface InvoiceItem {
    id: string;
    itemNo: string;
    price: number;
    description?: string;
    quantity: number;
}

export interface Order {
    id: string;
    name: string;
    items: InvoiceItem[];
    dealerId: string
}

export interface InvoiceData {
    invoiceID: string;
    builtTo: string;
    totalAmount: number;
    dueAmount: number;
    dueDate: string;
    status: string;
    taxSlab: string;
    items: InvoiceItem[];  
}