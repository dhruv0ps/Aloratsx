import { Color } from "./color";

interface Size {
    L: number;
    W: number;
    H: number;
}

interface Weight {
    value: number;
    unit: 'lb' | 'kg';
}

interface Childbase {
    SKU: string;
    name: string;
    color: Color;
    selling_price: number;
    cost_price: number;
    product_size?: Size;
    weight: Weight;
    status: string;
    imageUrl: string;
    stock: number;
    isActive: boolean;
}
export interface Child extends Childbase {
    image: File | null;
}

export interface ChildWithData extends Omit<Childbase, 'color'> {
    color: Color;
    image: {
        filename: string,
        path: string
    } | null
}