export interface Invoice {
    value: string;
    label: string; 
}

export interface Transaction {
    transactionId: string;
    transactionDate: string;
    dealer: string;
    invoiceId: string[]; 
}