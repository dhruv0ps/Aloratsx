import { Address } from "./address";
import { taxSlab } from "./taxslab";

export interface Dealerbase {
    username: string,
    email: string,
    mobile: string,
    designation: string,
    company: string,
    address: Address,
}
export interface DealerForm extends Dealerbase {
    province: string
}

export interface Dealer extends Dealerbase {
    _id: string,
    createdAt: string,
    updatedAt: string,
    province: taxSlab,
    name : string;
    id: string;

}


export interface ApprovedDealerBase {
    contactPersonName: string;
    contactPersonCell: string;
    contactPersonEmail: string;
    designation: string;
    companyName: string;
    address: Address;
    priceDiscount: number;
    emailId: string;
    password: string;
    creditDueDays: number;
    creditDueAmount: number;
}

export interface FormDataApprovedDealer extends ApprovedDealerBase {
    province: string;
}

export interface ApprovedDealer extends ApprovedDealerBase {
    _id: string,
    createdAt: string,
    updatedAt: string,
    province: taxSlab,
    status: string
}