import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import {
  createBrowserRouter,
  RouterProvider,
} from "react-router-dom";
import 'react-toastify/dist/ReactToastify.css';

import { Provider } from 'mobx-react';
import { authStore } from './store/authStore.ts';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import Home from './layout/Home.tsx';
import Dashboard from './features/Dashboard/Dashboard.tsx';
import { ToastContainer } from 'react-toastify';
import AddColor from './features/Products/ColorManage.tsx';
import CategoryManager from './features/Products/CategoryManage.tsx';
import AddProduct from './features/Products/ProductManage.tsx';
import ViewProducts from './features/Products/ViewProducts.tsx';
import AddDealer from './features/Dealer/DealerSignup.tsx';
import TaxSlabManage from './features/Dealer/DealerTaxSlabs.tsx';
import DealersApprovalList from './features/Dealer/DealerApprovals.tsx';
import DealerEditList from './features/Dealer/DealerEditList.tsx';
import DealersList from './features/Dealer/DealerList.tsx';
import OrderForm from './features/Orders/OrderRequest.tsx';
import OrderApprovalList from './features/Orders/OrderApprovals.tsx';
import Orders from './features/Orders/OrderView.tsx';
import Login from './features/DealerPortal/Login.tsx';
import PackingSlipList from './features/PackingSlip/PackingSlipList.tsx';
import AddPackingSlip from './features/PackingSlip/AddPackingSlip.tsx';
import ViewPackingSlip from './features/PackingSlip/ViewPackingSlip.tsx';
import AddOrderId from './features/PackingSlip/AddOrderId.tsx';
import InvoiceList from './features/Invoice/InvoiceList.tsx';
import AddInvoice from './features/Invoice/AddInvoice.tsx';
import InvoiceSummary from './features/Invoice/InvoiceSummary.tsx';
// import AddTransaction from './features/Transaction/AddTransaction.tsx';
import TransactionList from './features/Transaction/TransactionList.tsx';
import RecordTrans from './features/Transaction/RecordTrans.tsx';

const stores = { authStore };
const router = createBrowserRouter([
  {
    path: "/",
    element: <Home />, // Use MainLayout for routes that need the sidebar
    children: [
      {
        path: "/shopproducts",
        element: <Dashboard />,
      },
      {
        path: "/yellowadmin/products/color",
        element: <AddColor />,
      },
      {
        path: "/yellowadmin/products",
        element: <ViewProducts />,
      },
      {
        path: "/yellowadmin/products/category",
        element: <CategoryManager />,
      },
      {
        path: "/yellowadmin/products/add",
        element: <AddProduct />,
      },
      {
        path: "/products/manage/:id",
        element: <AddProduct />,
      },
      {
        path: "/dealer/signup",
        element: <AddDealer />,
      },
      {
        path: "/taxSlabs",
        element: <TaxSlabManage />,
      },
      {
        path: "/dealer/approvals",
        element: <DealersApprovalList />,
      },
      {
        path: "/dealer",
        element: <DealersList />,
      },
      {
        path: "/dealer/edit/:id",
        element: <DealerEditList />,
      },
      {
        path: "/appdealer/edit/:aid",
        element: <DealerEditList />,
      },
      {
        path: "/yellowadmin/orders/request",
        element: <OrderForm />,
      },
      {
        path: "/yellowadmin/orders/approvals",
        element: <OrderApprovalList />,
      },
      {
        path: "/yellowadmin/orders/approved",
        element: <Orders />,
      },
      {
        path: "/yellowadmin/PackingSlip/PackingSlipList",
        element: <PackingSlipList />,
      },
      {
        path: "/yellowadmin/PackingSlip/AddPackingSlip",
        element: <AddPackingSlip />,
      },
      {
        path: "/yellowadmin/PackingSlip/ViewPackingSlip",
        element: <ViewPackingSlip />,
      },
      {
        path: "/yellowadmin/PackingSlip/AddOrderId",
        element: <AddOrderId />,
      },
      {
        path: "/yellowadmin/PackingSlip/AddPackingSlip",
        element: <AddPackingSlip />,
      },
      {
        path: "/yellowadmin/PackingSlip/ViewPackingSlip",
        element: <ViewPackingSlip />,
      },
      {
        path: "/yellowadmin/PackingSlip/AddOrderId",
        element: <AddOrderId />,
      },
      {
        path: "/yellowadmin/PackingSlip/AddPackingSlip",
        element: <AddPackingSlip />,
      },
      {
        path: "/yellowadmin/PackingSlip/ViewPackingSlip",
        element: <ViewPackingSlip />,
      },
      {
        path: "/yellowadmin/PackingSlip/AddOrderId",
        element: <AddOrderId />,
      },
      {
        path: "/yellowadmin/Invoice/InvoiceList",
        element: <InvoiceList />,
      },
      {
        path: "/yellowadmin/Invoice/AddInvoice",
        element: <AddInvoice />,
      },
      {
        path: "/yellowadmin/Invoice/InvoiceSummary",
        element: <InvoiceSummary />,
      },
      {
        path: "/yellowadmin/Transaction/AddTransaction",
          element: <RecordTrans />,
      },
      {
        path: "/yellowadmin/Transaction/TransactionList",
        element: <TransactionList />,
      },
    
      // {
      //   path: "/yellowadmin/Transaction/AddTransaction/RecordTrans",
      //   element: <RecordTrans />,
      // },
    
      
    ]
  },
  {
    path: "/dealerportal/login",
    element: <Login />,
  },
  //NO sidebar or navbar pages
  // {
  //   path: "/login",
  //   element: <Login />,
  // },

]);



ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Provider {...stores}>
      <DndProvider backend={HTML5Backend}>
        <RouterProvider router={router} />
      </DndProvider>
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover />
    </Provider>
  </React.StrictMode>,

)
